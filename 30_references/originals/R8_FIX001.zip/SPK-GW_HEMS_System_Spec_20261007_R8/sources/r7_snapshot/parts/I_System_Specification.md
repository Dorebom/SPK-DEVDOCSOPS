<a id="part-i"></a>
# I. システム全体仕様

**文書状態：DRAFT_FOR_REVIEW。** 機能の一覧化・配賦整理であり、実装・機能採用・権限付与・対応機器の承認ではない。R6の27詳細章・124 SYS要求・69試験・85 OQは維持する。

## I.1 対象と読み方

住宅設備・GW・クラウド・端末・宅内ネットワークを含め、全体として何ができるかと誰が実現するかを記載する。GWに実装しないPCSの自律取得・系統保護、スマートフォン／クラウドの役割も全体機能に含める。

システム全体の一覧とGW一覧は二重記載ではなく、上位機能から各要素への配賦関係である。`S-FN-*`／`GW-FN-*`は本一覧の識別子で、既存`SYS-*`要求の改番や承認済みUSDMの新設ではない。

## I.2 システム全体の機能（要件）一覧

**21機能群。既存R6から抽出した設計・候補の一覧であり、既存実装の全機能棚卸し完了を意味しない。** 各行の詳細カードに適用条件・要求・OQを載せる。

| 全体機能ID | 機能（要求の要約） | 実現する要素 | 関係するGW機能 |
|---|---|---|---|
| [S-FN-001](I_System_Specification.md#s-fn-001) | エネルギー・設備状態の把握：機器と計測器の状態・電力等を、品質・鮮度とともに把握する。 | 機器・計測器＋GW＋表示先 | [GW-FN-008](II_GW_Product_Specification.md#gw-fn-008)、[GW-FN-009](II_GW_Product_Specification.md#gw-fn-009)、[GW-FN-012](II_GW_Product_Specification.md#gw-fn-012)、[GW-FN-016](II_GW_Product_Specification.md#gw-fn-016) |
| [S-FN-002](I_System_Specification.md#s-fn-002) | 宅内モニタリング・操作：宅内ブラウザから監視し、認可された操作と結果を確認する。 | 端末ブラウザ＋GW＋宅内LAN/AP（直接無線は別経路） | [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001)、[GW-FN-018](II_GW_Product_Specification.md#gw-fn-018) |
| [S-FN-003](I_System_Specification.md#s-fn-003) | リモートモニタリング・操作：スマートフォンアプリからクラウド経由で対象住宅を監視・操作する。 | アプリ＋クラウド＋宅内ルータ＋GW＋対象機器 | [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001)、[GW-FN-009](II_GW_Product_Specification.md#gw-fn-009)、[GW-FN-017](II_GW_Product_Specification.md#gw-fn-017)、[GW-FN-019](II_GW_Product_Specification.md#gw-fn-019) |
| [S-FN-004](I_System_Specification.md#s-fn-004) | PV・蓄電池等の通常運転：許可されたDER操作を実機へ届け、受理と観測による達成を区別する。 | GW＋PCS／DER | [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001)、[GW-FN-002](II_GW_Product_Specification.md#gw-fn-002)、[GW-FN-003](II_GW_Product_Specification.md#gw-fn-003)、[GW-FN-004](II_GW_Product_Specification.md#gw-fn-004)、[GW-FN-010](II_GW_Product_Specification.md#gw-fn-010)、[GW-FN-011](II_GW_Product_Specification.md#gw-fn-011)、[GW-FN-012](II_GW_Product_Specification.md#gw-fn-012) |
| [S-FN-005](I_System_Specification.md#s-fn-005) | 空調・給湯等の負荷操作：快適性・機器安全を尊重して、採用された負荷操作を実行する。 | GW＋空調・給湯等 | [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001)、[GW-FN-002](II_GW_Product_Specification.md#gw-fn-002)、[GW-FN-003](II_GW_Product_Specification.md#gw-fn-003)、[GW-FN-005](II_GW_Product_Specification.md#gw-fn-005)、[GW-FN-010](II_GW_Product_Specification.md#gw-fn-010)、[GW-FN-012](II_GW_Product_Specification.md#gw-fn-012) |
| [S-FN-006](I_System_Specification.md#s-fn-006) | 高度エネマネ運転計画：自家消費・料金・購入電力・充電期限等の採用戦略で運転を計画する。 | GW＋対応機器＋採用時の外部情報源 | [GW-FN-002](II_GW_Product_Specification.md#gw-fn-002)、[GW-FN-003](II_GW_Product_Specification.md#gw-fn-003)、[GW-FN-004](II_GW_Product_Specification.md#gw-fn-004)、[GW-FN-005](II_GW_Product_Specification.md#gw-fn-005)、[GW-FN-006](II_GW_Product_Specification.md#gw-fn-006) |
| [S-FN-007](I_System_Specification.md#s-fn-007) | 計画評価・再計画：実績・制約・機器離脱・入力不足を踏まえ、再計画又は縮退を行う。 | GW＋機器状態／観測 | [GW-FN-003](II_GW_Product_Specification.md#gw-fn-003)、[GW-FN-004](II_GW_Product_Specification.md#gw-fn-004)、[GW-FN-005](II_GW_Product_Specification.md#gw-fn-005)、[GW-FN-007](II_GW_Product_Specification.md#gw-fn-007)、[GW-FN-008](II_GW_Product_Specification.md#gw-fn-008)、[GW-FN-026](II_GW_Product_Specification.md#gw-fn-026) |
| [S-FN-008](I_System_Specification.md#s-fn-008) | 設備登録・接続構成管理：機器・物理設備・計測点・制御能力・版・接続を整合させる。 | GW＋機器＋認可された施工／管理主体 | [GW-FN-010](II_GW_Product_Specification.md#gw-fn-010)、[GW-FN-011](II_GW_Product_Specification.md#gw-fn-011)、[GW-FN-012](II_GW_Product_Specification.md#gw-fn-012)、[GW-FN-029](II_GW_Product_Specification.md#gw-fn-029)、[GW-FN-031](II_GW_Product_Specification.md#gw-fn-031) |
| [S-FN-009](I_System_Specification.md#s-fn-009) | 設定変更・保存・復元：許可した設定を世代管理し、希望・保存・有効状態と競合を区別する。 | 操作端末／上位＋GWの設定所有者 | [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001)、[GW-FN-017](II_GW_Product_Specification.md#gw-fn-017)、[GW-FN-020](II_GW_Product_Specification.md#gw-fn-020)、[GW-FN-021](II_GW_Product_Specification.md#gw-fn-021)、[GW-FN-030](II_GW_Product_Specification.md#gw-fn-030) |
| [S-FN-010](I_System_Specification.md#s-fn-010) | GW内部機能の操作：認可された開始停止・再探索・再起動等をJobとして実行する。 | 利用主体／上位＋GW | [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001)、[GW-FN-017](II_GW_Product_Specification.md#gw-fn-017)、[GW-FN-022](II_GW_Product_Specification.md#gw-fn-022) |
| [S-FN-011](I_System_Specification.md#s-fn-011) | FW配信・適用・復旧：配布物の承認・配送・検証・適用・復旧を別主体／段階で管理する。 | リリース承認主体＋FWサーバ＋GW | [GW-FN-023](II_GW_Product_Specification.md#gw-fn-023)、[GW-FN-024](II_GW_Product_Specification.md#gw-fn-024) |
| [S-FN-012](I_System_Specification.md#s-fn-012) | RS-485 PCSの遠隔出力制御：GW G側が宅内ルータ経由でスケジュールを取得・管理し、RS-485でPCSへ指示する。 | 出力制御サーバ＋ルータ＋GW G側＋RS-485 PCS | [GW-FN-011](II_GW_Product_Specification.md#gw-fn-011)、[GW-FN-014](II_GW_Product_Specification.md#gw-fn-014)、[GW-FN-015](II_GW_Product_Specification.md#gw-fn-015)、[GW-FN-028](II_GW_Product_Specification.md#gw-fn-028) |
| [S-FN-013](I_System_Specification.md#s-fn-013) | EL接続PCSの自律出力制御：PCS自身が宅内ルータ経由で取得・保存・適用する。GWを代理取得器にしない。 | 出力制御サーバ＋ルータ＋EL接続PCS | [GW-FN-016](II_GW_Product_Specification.md#gw-fn-016)、[GW-FN-028](II_GW_Product_Specification.md#gw-fn-028) |
| [S-FN-014](I_System_Specification.md#s-fn-014) | PCS側の系統連系保護：機器側の独立した保護を成立させ、HEMSの応答・承認を待たない。 | PCS等の確認対象保護機能 | [GW-FN-016](II_GW_Product_Specification.md#gw-fn-016)、[GW-FN-028](II_GW_Product_Specification.md#gw-fn-028) |
| [S-FN-015](I_System_Specification.md#s-fn-015) | 競合・通信断・停止・復旧の協調：通常要求の競合と、障害位置別の残留・失効・復旧を管理する。 | GW H/G＋PCS＋ネットワーク＋各サービス | [GW-FN-002](II_GW_Product_Specification.md#gw-fn-002)、[GW-FN-003](II_GW_Product_Specification.md#gw-fn-003)、[GW-FN-004](II_GW_Product_Specification.md#gw-fn-004)、[GW-FN-007](II_GW_Product_Specification.md#gw-fn-007)、[GW-FN-015](II_GW_Product_Specification.md#gw-fn-015)、[GW-FN-020](II_GW_Product_Specification.md#gw-fn-020)、[GW-FN-022](II_GW_Product_Specification.md#gw-fn-022)、[GW-FN-024](II_GW_Product_Specification.md#gw-fn-024)、[GW-FN-026](II_GW_Product_Specification.md#gw-fn-026)、[GW-FN-032](II_GW_Product_Specification.md#gw-fn-032) |
| [S-FN-016](I_System_Specification.md#s-fn-016) | 警報・通知・診断：異常と操作結果を記録・通知し、公開範囲内で診断可能にする。 | GW＋クラウド／UI＋機器 | [GW-FN-008](II_GW_Product_Specification.md#gw-fn-008)、[GW-FN-009](II_GW_Product_Specification.md#gw-fn-009)、[GW-FN-016](II_GW_Product_Specification.md#gw-fn-016)、[GW-FN-017](II_GW_Product_Specification.md#gw-fn-017)、[GW-FN-019](II_GW_Product_Specification.md#gw-fn-019)、[GW-FN-022](II_GW_Product_Specification.md#gw-fn-022)、[GW-FN-025](II_GW_Product_Specification.md#gw-fn-025) |
| [S-FN-017](I_System_Specification.md#s-fn-017) | 履歴の保存・提出・利用：用途別のデータを保持し、期間・品質・欠測を明示して抽出する。 | GW＋採用するクラウド保存／利用先 | [GW-FN-008](II_GW_Product_Specification.md#gw-fn-008)、[GW-FN-009](II_GW_Product_Specification.md#gw-fn-009) |
| [S-FN-018](I_System_Specification.md#s-fn-018) | 外部HEMSとの機器公開連携：GWがDevice側として許可する情報・操作を外部HEMSへ提供する。 | 外部HEMS＋GW＋実機対応 | [GW-FN-013](II_GW_Product_Specification.md#gw-fn-013) |
| [S-FN-019](I_System_Specification.md#s-fn-019) | 利用者識別・権限・所属管理：4種類の利用者に対して、認可・失効・対象範囲・監査を適用する。 | 利用者＋GW／クラウド／製造保守の各認可境界 | [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001)、[GW-FN-017](II_GW_Product_Specification.md#gw-fn-017)、[GW-FN-025](II_GW_Product_Specification.md#gw-fn-025)、[GW-FN-027](II_GW_Product_Specification.md#gw-fn-027)、[GW-FN-028](II_GW_Product_Specification.md#gw-fn-028)、[GW-FN-030](II_GW_Product_Specification.md#gw-fn-030) |
| [S-FN-020](I_System_Specification.md#s-fn-020) | 製造・施工・保守・交換・廃棄支援：個体識別から引渡し、交換、所有者変更、消去まで必要な支援を定義する。 | メーカー／メンテナンス／ユーザ＋GW＋支援基盤 | [GW-FN-010](II_GW_Product_Specification.md#gw-fn-010)、[GW-FN-020](II_GW_Product_Specification.md#gw-fn-020)、[GW-FN-022](II_GW_Product_Specification.md#gw-fn-022)、[GW-FN-025](II_GW_Product_Specification.md#gw-fn-025)、[GW-FN-027](II_GW_Product_Specification.md#gw-fn-027)、[GW-FN-029](II_GW_Product_Specification.md#gw-fn-029)、[GW-FN-030](II_GW_Product_Specification.md#gw-fn-030)、[GW-FN-032](II_GW_Product_Specification.md#gw-fn-032) |
| [S-FN-021](I_System_Specification.md#s-fn-021) | 通信・周辺機器の構成と復旧：通信方式・USB等の採用条件、接続・故障・復旧を管理する。 | GW＋宅内ルータ＋周辺機器 | [GW-FN-021](II_GW_Product_Specification.md#gw-fn-021)、[GW-FN-026](II_GW_Product_Specification.md#gw-fn-026)、[GW-FN-031](II_GW_Product_Specification.md#gw-fn-031) |

## I.3 システム利用者と機能範囲

| 利用者分類（確定） | 役割範囲の案（権限は未承認） |
|---|---|
| ユーザ | 所有・利用する住宅の監視、許可された通常運転・利用者設定 |
| メンテナンス | 委託された設備の施工・点検・診断・許可された復旧 |
| メーカー | 製品個体・リリース・配信・承認された保守の管理 |
| 開発者 | 開発・試験環境の検証と、別途認可された限定診断 |

4つは利用者の種類であり、権限の上下4段階ではない。メーカー又は開発者を全機能の管理者にしない。1人の複数役割、役割切替、兼任可否、委任対象・期限は未確定。施工者・運用者等のR6表現を新たな第5ロールとせず、4分類への対応を確認する。

本編はロールの定義、利用場面、機能群ごとの概要、通常APIからの禁止事項を保持する。詳細は[利用者別機能・操作権限別冊](../appendices/Role_Function_Access.md)を文書ID・版で規範参照する。手順書や画面非表示だけを認可の正本にしない。自動EMS、上位サービス、配信サービス等の機械主体は人の4分類とは別に識別する。

## I.4 機器構成パターン

| 構成ID／代表型 | 出力制御スケジュールの取得・適用主体 | 通常操作・観測 | 適合状態 |
|---|---|---|---|
| [CFG-RS RS-485接続PCS構成](../appendices/Configuration_Patterns.md#cfg-rs) | GW G側 | GW G側 ⇄ RS-485 ⇄ PCS | 型式・版・台数・共存条件は未確認 |
| [CFG-EL ECHONET Lite接続PCS構成](../appendices/Configuration_Patterns.md#cfg-el) | 各対象PCSの出力制御機能 | GW H側 EL Controller ⇄ 宅内LAN/AP ⇄ PCS EL機器IF | 型式・版・台数・共存条件は未確認 |
| [CFG-MIX RS-485＋ECHONET Lite PCS混在構成](../appendices/Configuration_Patterns.md#cfg-mix) | RS-485対象はGW G側、EL対象は当該PCS | RS-485必須指令経路とEL通常操作経路を独立識別 | 型式・版・台数・共存条件は未確認 |

本編に責務・経路が異なる代表パターンを残す。メーカー・型式・FW・台数・配線・プロパティ差の全組合せは[構成パターン別冊](../appendices/Configuration_Patterns.md)に展開する。構成別の対応機能は「あり／なし」だけでなく、条件付き・非対応・未確認を分ける。

すべての出力制御サーバ通信は宅内ルータ経由。EL接続PCSだけがGW非経由で取得し、RS-485接続PCSはGW G側が取得・管理・指示する。これを単なる選択メニューで入替えない。

## I.5 既存詳細章との対応

| 既存章 | 扱う内容 |
|---|---|
| [01. 文書管理・適用範囲・仕様の確定度](../chapters/01_Scope_Baseline.md) | 文書管理・適用範囲・仕様の確定度 |
| [02. 外部サービス・宅内接続を含むシステム構成](../chapters/02_System_Context.md) | 外部サービス・宅内接続を含むシステム構成 |
| [04. 製品構成・機器分類・接続プロファイル](../chapters/04_Configurations_Profiles.md) | 製品構成・機器分類・接続プロファイル |
| [06. システムユースケース・横断振る舞い](../chapters/06_Usecases.md) | システムユースケース・横断振る舞い |
| [10. 一般送配電事業者・遠隔出力制御・系統連系保護](../chapters/10_Grid_Protection.md) | 一般送配電事業者・遠隔出力制御・系統連系保護 |
| [11. 電力制約・トポロジー・過渡条件](../chapters/11_Power_Constraints.md) | 電力制約・トポロジー・過渡条件 |
| [21. 出力制御接続方式の選択・責務・切替](../chapters/21_Grid_Connection_Selection.md) | 出力制御接続方式の選択・責務・切替 |

## I.6 全体機能の適用条件・根拠カード

<a id="s-fn-001"></a>

### S-FN-001 — エネルギー・設備状態の把握

機器と計測器の状態・電力等を、品質・鮮度とともに把握する。

**適用条件：** 対応する計測能力と計測点が確定する構成

**実現責任：** 機器・計測器＋GW＋表示先

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-008](II_GW_Product_Specification.md#gw-fn-008) ／ [GW-FN-009](II_GW_Product_Specification.md#gw-fn-009) ／ [GW-FN-012](II_GW_Product_Specification.md#gw-fn-012) ／ [GW-FN-016](II_GW_Product_Specification.md#gw-fn-016)

**関連SYS要求：** [SYS-CAP-001](../appendices/Requirements_Catalog.md)、[SYS-DATA-001](../appendices/Requirements_Catalog.md)、[SYS-DATA-002](../appendices/Requirements_Catalog.md)、[SYS-EL-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-004](../appendices/Requirements_Catalog.md)、[SYS-GNET-007](../appendices/Requirements_Catalog.md)、[SYS-GSEL-013](../appendices/Requirements_Catalog.md)、[SYS-GSEL-014](../appendices/Requirements_Catalog.md)、[SYS-MEAS-001](../appendices/Requirements_Catalog.md)、[SYS-MEAS-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-006](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-002](../appendices/Requirements_Catalog.md)

**根拠本文：** [02_System_Context](../chapters/02_System_Context.md)<br/>[09_Measurement_Data](../chapters/09_Measurement_Data.md)<br/>[11_Power_Constraints](../chapters/11_Power_Constraints.md)

**残る確認：** [OQ-R6-09-01](../chapters/09_Measurement_Data.md#oq-r6-09-01)



<a id="s-fn-002"></a>

### S-FN-002 — 宅内モニタリング・操作

宅内ブラウザから監視し、認可された操作と結果を確認する。

**適用条件：** 直接無線／ルータ経由。採用条件は個別確定

**実現責任：** 端末ブラウザ＋GW＋宅内LAN/AP（直接無線は別経路）

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001) ／ [GW-FN-018](II_GW_Product_Specification.md#gw-fn-018)

**関連SYS要求：** [SYS-GNET-010](../appendices/Requirements_Catalog.md)、[SYS-NORTH-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-007](../appendices/Requirements_Catalog.md)、[SYS-REQ-001](../appendices/Requirements_Catalog.md)、[SYS-UI-001](../appendices/Requirements_Catalog.md)、[SYS-UI-002](../appendices/Requirements_Catalog.md)、[SYS-UI-003](../appendices/Requirements_Catalog.md)、[SYS-UI-004](../appendices/Requirements_Catalog.md)、[SYS-UI-005](../appendices/Requirements_Catalog.md)

**根拠本文：** [02_System_Context](../chapters/02_System_Context.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-02-02](../chapters/02_System_Context.md#oq-r6-02-02) ／ [OQ-R6-20-02](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-02)



<a id="s-fn-003"></a>

### S-FN-003 — リモートモニタリング・操作

スマートフォンアプリからクラウド経由で対象住宅を監視・操作する。

**適用条件：** GWはアプリの実装主体ではない

**実現責任：** アプリ＋クラウド＋宅内ルータ＋GW＋対象機器

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001) ／ [GW-FN-009](II_GW_Product_Specification.md#gw-fn-009) ／ [GW-FN-017](II_GW_Product_Specification.md#gw-fn-017) ／ [GW-FN-019](II_GW_Product_Specification.md#gw-fn-019)

**関連SYS要求：** [SYS-APP-001](../appendices/Requirements_Catalog.md)、[SYS-APP-002](../appendices/Requirements_Catalog.md)、[SYS-DATA-001](../appendices/Requirements_Catalog.md)、[SYS-DATA-002](../appendices/Requirements_Catalog.md)、[SYS-GWOP-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-003](../appendices/Requirements_Catalog.md)、[SYS-NORTH-004](../appendices/Requirements_Catalog.md)、[SYS-NORTH-005](../appendices/Requirements_Catalog.md)、[SYS-NORTH-006](../appendices/Requirements_Catalog.md)、[SYS-NORTH-007](../appendices/Requirements_Catalog.md)、[SYS-REQ-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-002](../appendices/Requirements_Catalog.md)

**根拠本文：** [20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-20-01](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-01) ／ [OQ-R6-20-02](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-02)



<a id="s-fn-004"></a>

### S-FN-004 — PV・蓄電池等の通常運転

許可されたDER操作を実機へ届け、受理と観測による達成を区別する。

**適用条件：** RS-485／ELの能力と更新間隔を別確認

**実現責任：** GW＋PCS／DER

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001) ／ [GW-FN-002](II_GW_Product_Specification.md#gw-fn-002) ／ [GW-FN-003](II_GW_Product_Specification.md#gw-fn-003) ／ [GW-FN-004](II_GW_Product_Specification.md#gw-fn-004) ／ [GW-FN-010](II_GW_Product_Specification.md#gw-fn-010) ／ [GW-FN-011](II_GW_Product_Specification.md#gw-fn-011) ／ [GW-FN-012](II_GW_Product_Specification.md#gw-fn-012)

**関連SYS要求：** [SYS-AUTH-001](../appendices/Requirements_Catalog.md)、[SYS-AUTH-002](../appendices/Requirements_Catalog.md)、[SYS-CAP-001](../appendices/Requirements_Catalog.md)、[SYS-CAP-002](../appendices/Requirements_Catalog.md)、[SYS-COEX-001](../appendices/Requirements_Catalog.md)、[SYS-EL-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-004](../appendices/Requirements_Catalog.md)、[SYS-GNET-012](../appendices/Requirements_Catalog.md)、[SYS-NORTH-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-007](../appendices/Requirements_Catalog.md)、[SYS-ORCH-001](../appendices/Requirements_Catalog.md)、[SYS-REQ-001](../appendices/Requirements_Catalog.md)、[SYS-RESP-001](../appendices/Requirements_Catalog.md)、[SYS-RESULT-001](../appendices/Requirements_Catalog.md)、[SYS-RESULT-002](../appendices/Requirements_Catalog.md)、[SYS-RESULT-003](../appendices/Requirements_Catalog.md)、[SYS-RETRY-001](../appendices/Requirements_Catalog.md)、[SYS-ROUTE-001](../appendices/Requirements_Catalog.md)、[SYS-RS-001](../appendices/Requirements_Catalog.md)、[SYS-RS-002](../appendices/Requirements_Catalog.md)、[SYS-RS-003](../appendices/Requirements_Catalog.md)、[SYS-RS-005](../appendices/Requirements_Catalog.md)、[SYS-RS-006](../appendices/Requirements_Catalog.md)、[SYS-SEM-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [05_Control_Contracts](../chapters/05_Control_Contracts.md)<br/>[07_DER_Connections](../chapters/07_DER_Connections.md)

**残る確認：** [OQ-R6-07-01](../chapters/07_DER_Connections.md#oq-r6-07-01) ／ [OQ-R6-07-02](../chapters/07_DER_Connections.md#oq-r6-07-02)



<a id="s-fn-005"></a>

### S-FN-005 — 空調・給湯等の負荷操作

快適性・機器安全を尊重して、採用された負荷操作を実行する。

**適用条件：** 必要なELプロパティ・機器能力を確認

**実現責任：** GW＋空調・給湯等

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001) ／ [GW-FN-002](II_GW_Product_Specification.md#gw-fn-002) ／ [GW-FN-003](II_GW_Product_Specification.md#gw-fn-003) ／ [GW-FN-005](II_GW_Product_Specification.md#gw-fn-005) ／ [GW-FN-010](II_GW_Product_Specification.md#gw-fn-010) ／ [GW-FN-012](II_GW_Product_Specification.md#gw-fn-012)

**関連SYS要求：** [SYS-AUTH-001](../appendices/Requirements_Catalog.md)、[SYS-AUTH-002](../appendices/Requirements_Catalog.md)、[SYS-CAP-001](../appendices/Requirements_Catalog.md)、[SYS-CAP-002](../appendices/Requirements_Catalog.md)、[SYS-COEX-001](../appendices/Requirements_Catalog.md)、[SYS-EL-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-004](../appendices/Requirements_Catalog.md)、[SYS-GNET-012](../appendices/Requirements_Catalog.md)、[SYS-LOAD-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-007](../appendices/Requirements_Catalog.md)、[SYS-ORCH-001](../appendices/Requirements_Catalog.md)、[SYS-REQ-001](../appendices/Requirements_Catalog.md)、[SYS-RETRY-001](../appendices/Requirements_Catalog.md)、[SYS-ROUTE-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [08_Advanced_EMS_Loads](../chapters/08_Advanced_EMS_Loads.md)

**残る確認：** [OQ-R6-08-03](../chapters/08_Advanced_EMS_Loads.md#oq-r6-08-03)



<a id="s-fn-006"></a>

### S-FN-006 — 高度エネマネ運転計画

自家消費・料金・購入電力・充電期限等の採用戦略で運転を計画する。

**適用条件：** 候補戦略を初回必須としない

**実現責任：** GW＋対応機器＋採用時の外部情報源

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-002](II_GW_Product_Specification.md#gw-fn-002) ／ [GW-FN-003](II_GW_Product_Specification.md#gw-fn-003) ／ [GW-FN-004](II_GW_Product_Specification.md#gw-fn-004) ／ [GW-FN-005](II_GW_Product_Specification.md#gw-fn-005) ／ [GW-FN-006](II_GW_Product_Specification.md#gw-fn-006)

**関連SYS要求：** [SYS-AUTH-001](../appendices/Requirements_Catalog.md)、[SYS-AUTH-002](../appendices/Requirements_Catalog.md)、[SYS-COEX-001](../appendices/Requirements_Catalog.md)、[SYS-CONST-001](../appendices/Requirements_Catalog.md)、[SYS-EMS-001](../appendices/Requirements_Catalog.md)、[SYS-LOAD-001](../appendices/Requirements_Catalog.md)、[SYS-ORCH-001](../appendices/Requirements_Catalog.md)、[SYS-RESP-001](../appendices/Requirements_Catalog.md)、[SYS-RESULT-001](../appendices/Requirements_Catalog.md)、[SYS-RESULT-002](../appendices/Requirements_Catalog.md)、[SYS-RESULT-003](../appendices/Requirements_Catalog.md)、[SYS-RETRY-001](../appendices/Requirements_Catalog.md)、[SYS-SEM-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [08_Advanced_EMS_Loads](../chapters/08_Advanced_EMS_Loads.md)

**残る確認：** [OQ-R6-08-01](../chapters/08_Advanced_EMS_Loads.md#oq-r6-08-01) ／ [OQ-R6-08-02](../chapters/08_Advanced_EMS_Loads.md#oq-r6-08-02)



<a id="s-fn-007"></a>

### S-FN-007 — 計画評価・再計画

実績・制約・機器離脱・入力不足を踏まえ、再計画又は縮退を行う。

**適用条件：** 達成条件と原因不明の扱いを区別

**実現責任：** GW＋機器状態／観測

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-003](II_GW_Product_Specification.md#gw-fn-003) ／ [GW-FN-004](II_GW_Product_Specification.md#gw-fn-004) ／ [GW-FN-005](II_GW_Product_Specification.md#gw-fn-005) ／ [GW-FN-007](II_GW_Product_Specification.md#gw-fn-007) ／ [GW-FN-008](II_GW_Product_Specification.md#gw-fn-008) ／ [GW-FN-026](II_GW_Product_Specification.md#gw-fn-026)

**関連SYS要求：** [SYS-CONST-001](../appendices/Requirements_Catalog.md)、[SYS-EMS-001](../appendices/Requirements_Catalog.md)、[SYS-EXPIRY-001](../appendices/Requirements_Catalog.md)、[SYS-FAULT-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-005](../appendices/Requirements_Catalog.md)、[SYS-LOAD-001](../appendices/Requirements_Catalog.md)、[SYS-MEAS-001](../appendices/Requirements_Catalog.md)、[SYS-MEAS-002](../appendices/Requirements_Catalog.md)、[SYS-ORCH-001](../appendices/Requirements_Catalog.md)、[SYS-RESP-001](../appendices/Requirements_Catalog.md)、[SYS-RESULT-001](../appendices/Requirements_Catalog.md)、[SYS-RESULT-002](../appendices/Requirements_Catalog.md)、[SYS-RESULT-003](../appendices/Requirements_Catalog.md)、[SYS-RETRY-001](../appendices/Requirements_Catalog.md)、[SYS-SEM-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-002](../appendices/Requirements_Catalog.md)

**根拠本文：** [06_Usecases](../chapters/06_Usecases.md)<br/>[08_Advanced_EMS_Loads](../chapters/08_Advanced_EMS_Loads.md)<br/>[13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)

**残る確認：** [OQ-R6-08-02](../chapters/08_Advanced_EMS_Loads.md#oq-r6-08-02)



<a id="s-fn-008"></a>

### S-FN-008 — 設備登録・接続構成管理

機器・物理設備・計測点・制御能力・版・接続を整合させる。

**適用条件：** 検出だけで全操作対応にしない

**実現責任：** GW＋機器＋認可された施工／管理主体

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-010](II_GW_Product_Specification.md#gw-fn-010) ／ [GW-FN-011](II_GW_Product_Specification.md#gw-fn-011) ／ [GW-FN-012](II_GW_Product_Specification.md#gw-fn-012) ／ [GW-FN-029](II_GW_Product_Specification.md#gw-fn-029) ／ [GW-FN-031](II_GW_Product_Specification.md#gw-fn-031)

**関連SYS要求：** [SYS-CAP-001](../appendices/Requirements_Catalog.md)、[SYS-CAP-002](../appendices/Requirements_Catalog.md)、[SYS-EL-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-004](../appendices/Requirements_Catalog.md)、[SYS-GNET-012](../appendices/Requirements_Catalog.md)、[SYS-GSEL-019](../appendices/Requirements_Catalog.md)、[SYS-MIG-002](../appendices/Requirements_Catalog.md)、[SYS-ROUTE-001](../appendices/Requirements_Catalog.md)、[SYS-RS-001](../appendices/Requirements_Catalog.md)、[SYS-RS-002](../appendices/Requirements_Catalog.md)、[SYS-RS-003](../appendices/Requirements_Catalog.md)、[SYS-RS-005](../appendices/Requirements_Catalog.md)、[SYS-RS-006](../appendices/Requirements_Catalog.md)、[SYS-SEC-001](../appendices/Requirements_Catalog.md)、[SYS-SVC-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [04_Configurations_Profiles](../chapters/04_Configurations_Profiles.md)<br/>[07_DER_Connections](../chapters/07_DER_Connections.md)<br/>[26_Manufacturing_Commissioning_Retirement](../chapters/26_Manufacturing_Commissioning_Retirement.md)

**残る確認：** [OQ-R6-04-02](../chapters/04_Configurations_Profiles.md#oq-r6-04-02) ／ [OQ-R6-04-03](../chapters/04_Configurations_Profiles.md#oq-r6-04-03)



<a id="s-fn-009"></a>

### S-FN-009 — 設定変更・保存・復元

許可した設定を世代管理し、希望・保存・有効状態と競合を区別する。

**適用条件：** G側系統設定は通常設定と別契約

**実現責任：** 操作端末／上位＋GWの設定所有者

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001) ／ [GW-FN-017](II_GW_Product_Specification.md#gw-fn-017) ／ [GW-FN-020](II_GW_Product_Specification.md#gw-fn-020) ／ [GW-FN-021](II_GW_Product_Specification.md#gw-fn-021) ／ [GW-FN-030](II_GW_Product_Specification.md#gw-fn-030)

**関連SYS要求：** [SYS-APP-003](../appendices/Requirements_Catalog.md)、[SYS-CFG-001](../appendices/Requirements_Catalog.md)、[SYS-CFG-002](../appendices/Requirements_Catalog.md)、[SYS-CFG-003](../appendices/Requirements_Catalog.md)、[SYS-CFG-004](../appendices/Requirements_Catalog.md)、[SYS-CFG-005](../appendices/Requirements_Catalog.md)、[SYS-CFG-006](../appendices/Requirements_Catalog.md)、[SYS-GNET-006](../appendices/Requirements_Catalog.md)、[SYS-GSEL-019](../appendices/Requirements_Catalog.md)、[SYS-GWOP-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-003](../appendices/Requirements_Catalog.md)、[SYS-NORTH-004](../appendices/Requirements_Catalog.md)、[SYS-NORTH-005](../appendices/Requirements_Catalog.md)、[SYS-NORTH-007](../appendices/Requirements_Catalog.md)、[SYS-REQ-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [12_Configuration_Lifecycle](../chapters/12_Configuration_Lifecycle.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-12-02](../chapters/12_Configuration_Lifecycle.md#oq-r6-12-02) ／ [OQ-R6-12-03](../chapters/12_Configuration_Lifecycle.md#oq-r6-12-03) ／ [OQ-R6-12-04](../chapters/12_Configuration_Lifecycle.md#oq-r6-12-04)



<a id="s-fn-010"></a>

### S-FN-010 — GW内部機能の操作

認可された開始停止・再探索・再起動等をJobとして実行する。

**適用条件：** 任意shell・内部RPCの無制限公開ではない

**実現責任：** 利用主体／上位＋GW

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001) ／ [GW-FN-017](II_GW_Product_Specification.md#gw-fn-017) ／ [GW-FN-022](II_GW_Product_Specification.md#gw-fn-022)

**関連SYS要求：** [SYS-GWOP-001](../appendices/Requirements_Catalog.md)、[SYS-GWOP-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-003](../appendices/Requirements_Catalog.md)、[SYS-NORTH-004](../appendices/Requirements_Catalog.md)、[SYS-NORTH-005](../appendices/Requirements_Catalog.md)、[SYS-NORTH-007](../appendices/Requirements_Catalog.md)、[SYS-REQ-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-20-01](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-01)



<a id="s-fn-011"></a>

### S-FN-011 — FW配信・適用・復旧

配布物の承認・配送・検証・適用・復旧を別主体／段階で管理する。

**適用条件：** 対象領域とG側独立更新を別管理

**実現責任：** リリース承認主体＋FWサーバ＋GW

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-023](II_GW_Product_Specification.md#gw-fn-023) ／ [GW-FN-024](II_GW_Product_Specification.md#gw-fn-024)

**関連SYS要求：** [SYS-FW-001](../appendices/Requirements_Catalog.md)、[SYS-FW-002](../appendices/Requirements_Catalog.md)、[SYS-FW-003](../appendices/Requirements_Catalog.md)、[SYS-FW-004](../appendices/Requirements_Catalog.md)、[SYS-FW-005](../appendices/Requirements_Catalog.md)、[SYS-OTA-001](../appendices/Requirements_Catalog.md)、[SYS-OTA-002](../appendices/Requirements_Catalog.md)

**根拠本文：** [13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-20-04](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-04)



<a id="s-fn-012"></a>

### S-FN-012 — RS-485 PCSの遠隔出力制御

GW G側が宅内ルータ経由でスケジュールを取得・管理し、RS-485でPCSへ指示する。

**適用条件：** GW_MANAGED。H側通常EMSから独立

**実現責任：** 出力制御サーバ＋ルータ＋GW G側＋RS-485 PCS

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-011](II_GW_Product_Specification.md#gw-fn-011) ／ [GW-FN-014](II_GW_Product_Specification.md#gw-fn-014) ／ [GW-FN-015](II_GW_Product_Specification.md#gw-fn-015) ／ [GW-FN-028](II_GW_Product_Specification.md#gw-fn-028)

**関連SYS要求：** [SYS-BOUND-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-003](../appendices/Requirements_Catalog.md)、[SYS-GRID-001](../appendices/Requirements_Catalog.md)、[SYS-GRID-003](../appendices/Requirements_Catalog.md)、[SYS-GSEL-001](../appendices/Requirements_Catalog.md)、[SYS-GSEL-004](../appendices/Requirements_Catalog.md)、[SYS-GSEL-005](../appendices/Requirements_Catalog.md)、[SYS-GSEL-006](../appendices/Requirements_Catalog.md)、[SYS-GSEL-011](../appendices/Requirements_Catalog.md)、[SYS-GSEL-012](../appendices/Requirements_Catalog.md)、[SYS-OTA-001](../appendices/Requirements_Catalog.md)、[SYS-RS-001](../appendices/Requirements_Catalog.md)、[SYS-RS-002](../appendices/Requirements_Catalog.md)、[SYS-RS-003](../appendices/Requirements_Catalog.md)、[SYS-RS-005](../appendices/Requirements_Catalog.md)、[SYS-RS-006](../appendices/Requirements_Catalog.md)

**根拠本文：** [10_Grid_Protection](../chapters/10_Grid_Protection.md)<br/>[21_Grid_Connection_Selection](../chapters/21_Grid_Connection_Selection.md)

**残る確認：** [OQ-R6-10-01](../chapters/10_Grid_Protection.md#oq-r6-10-01) ／ [OQ-R6-21-01](../chapters/21_Grid_Connection_Selection.md#oq-r6-21-01)



<a id="s-fn-013"></a>

### S-FN-013 — EL接続PCSの自律出力制御

PCS自身が宅内ルータ経由で取得・保存・適用する。GWを代理取得器にしない。

**適用条件：** PCS_DIRECTはEL接続PCSのみ。GW配賦は参照・非迂回支援

**実現責任：** 出力制御サーバ＋ルータ＋EL接続PCS

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-016](II_GW_Product_Specification.md#gw-fn-016) ／ [GW-FN-028](II_GW_Product_Specification.md#gw-fn-028)

**関連SYS要求：** [SYS-BOUND-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-002](../appendices/Requirements_Catalog.md)、[SYS-GNET-004](../appendices/Requirements_Catalog.md)、[SYS-GNET-007](../appendices/Requirements_Catalog.md)、[SYS-GRID-001](../appendices/Requirements_Catalog.md)、[SYS-GSEL-004](../appendices/Requirements_Catalog.md)、[SYS-GSEL-006](../appendices/Requirements_Catalog.md)、[SYS-GSEL-013](../appendices/Requirements_Catalog.md)、[SYS-GSEL-014](../appendices/Requirements_Catalog.md)、[SYS-OTA-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [10_Grid_Protection](../chapters/10_Grid_Protection.md)<br/>[21_Grid_Connection_Selection](../chapters/21_Grid_Connection_Selection.md)

**残る確認：** [OQ-R6-21-01](../chapters/21_Grid_Connection_Selection.md#oq-r6-21-01)



<a id="s-fn-014"></a>

### S-FN-014 — PCS側の系統連系保護

機器側の独立した保護を成立させ、HEMSの応答・承認を待たない。

**適用条件：** GWは状態参照と迂回防止のみ。保護そのものはGW機能に数えない

**実現責任：** PCS等の確認対象保護機能

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-016](II_GW_Product_Specification.md#gw-fn-016) ／ [GW-FN-028](II_GW_Product_Specification.md#gw-fn-028)

**関連SYS要求：** [SYS-BOUND-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-004](../appendices/Requirements_Catalog.md)、[SYS-GNET-007](../appendices/Requirements_Catalog.md)、[SYS-GRID-002](../appendices/Requirements_Catalog.md)、[SYS-GSEL-004](../appendices/Requirements_Catalog.md)、[SYS-GSEL-006](../appendices/Requirements_Catalog.md)、[SYS-GSEL-013](../appendices/Requirements_Catalog.md)、[SYS-GSEL-014](../appendices/Requirements_Catalog.md)、[SYS-OTA-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [10_Grid_Protection](../chapters/10_Grid_Protection.md)<br/>[15_Deployment_Isolation](../chapters/15_Deployment_Isolation.md)

**残る確認：** [OQ-R6-10-02](../chapters/10_Grid_Protection.md#oq-r6-10-02)



<a id="s-fn-015"></a>

### S-FN-015 — 競合・通信断・停止・復旧の協調

通常要求の競合と、障害位置別の残留・失効・復旧を管理する。

**適用条件：** H停止・GW全体停止・ルータ停止を分離

**実現責任：** GW H/G＋PCS＋ネットワーク＋各サービス

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-002](II_GW_Product_Specification.md#gw-fn-002) ／ [GW-FN-003](II_GW_Product_Specification.md#gw-fn-003) ／ [GW-FN-004](II_GW_Product_Specification.md#gw-fn-004) ／ [GW-FN-007](II_GW_Product_Specification.md#gw-fn-007) ／ [GW-FN-015](II_GW_Product_Specification.md#gw-fn-015) ／ [GW-FN-020](II_GW_Product_Specification.md#gw-fn-020) ／ [GW-FN-022](II_GW_Product_Specification.md#gw-fn-022) ／ [GW-FN-024](II_GW_Product_Specification.md#gw-fn-024) ／ [GW-FN-026](II_GW_Product_Specification.md#gw-fn-026) ／ [GW-FN-032](II_GW_Product_Specification.md#gw-fn-032)

**関連SYS要求：** [SYS-AUTH-001](../appendices/Requirements_Catalog.md)、[SYS-AUTH-002](../appendices/Requirements_Catalog.md)、[SYS-CAP-002](../appendices/Requirements_Catalog.md)、[SYS-CFG-001](../appendices/Requirements_Catalog.md)、[SYS-CFG-002](../appendices/Requirements_Catalog.md)、[SYS-CFG-004](../appendices/Requirements_Catalog.md)、[SYS-CFG-005](../appendices/Requirements_Catalog.md)、[SYS-COEX-001](../appendices/Requirements_Catalog.md)、[SYS-CONST-001](../appendices/Requirements_Catalog.md)、[SYS-EMS-001](../appendices/Requirements_Catalog.md)、[SYS-EXPIRY-001](../appendices/Requirements_Catalog.md)、[SYS-FAULT-001](../appendices/Requirements_Catalog.md)、[SYS-FW-003](../appendices/Requirements_Catalog.md)、[SYS-FW-004](../appendices/Requirements_Catalog.md)、[SYS-GNET-003](../appendices/Requirements_Catalog.md)、[SYS-GNET-005](../appendices/Requirements_Catalog.md)、[SYS-GSEL-004](../appendices/Requirements_Catalog.md)、[SYS-GSEL-005](../appendices/Requirements_Catalog.md)、[SYS-GSEL-011](../appendices/Requirements_Catalog.md)、[SYS-GSEL-012](../appendices/Requirements_Catalog.md)、[SYS-GWOP-001](../appendices/Requirements_Catalog.md)、[SYS-GWOP-002](../appendices/Requirements_Catalog.md)、[SYS-ORCH-001](../appendices/Requirements_Catalog.md)、[SYS-OTA-001](../appendices/Requirements_Catalog.md)、[SYS-OTA-002](../appendices/Requirements_Catalog.md)、[SYS-RESP-001](../appendices/Requirements_Catalog.md)、[SYS-RESULT-001](../appendices/Requirements_Catalog.md)、[SYS-RESULT-002](../appendices/Requirements_Catalog.md)、[SYS-RESULT-003](../appendices/Requirements_Catalog.md)、[SYS-RETRY-001](../appendices/Requirements_Catalog.md)、[SYS-SEM-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [05_Control_Contracts](../chapters/05_Control_Contracts.md)<br/>[13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)<br/>[21_Grid_Connection_Selection](../chapters/21_Grid_Connection_Selection.md)

**残る確認：** [OQ-R6-05-01](../chapters/05_Control_Contracts.md#oq-r6-05-01) ／ [OQ-R6-13-01](../chapters/13_Fault_Recovery_OTA.md#oq-r6-13-01)



<a id="s-fn-016"></a>

### S-FN-016 — 警報・通知・診断

異常と操作結果を記録・通知し、公開範囲内で診断可能にする。

**適用条件：** 情報の鮮度・権限・通知先を個別確定

**実現責任：** GW＋クラウド／UI＋機器

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-008](II_GW_Product_Specification.md#gw-fn-008) ／ [GW-FN-009](II_GW_Product_Specification.md#gw-fn-009) ／ [GW-FN-016](II_GW_Product_Specification.md#gw-fn-016) ／ [GW-FN-017](II_GW_Product_Specification.md#gw-fn-017) ／ [GW-FN-019](II_GW_Product_Specification.md#gw-fn-019) ／ [GW-FN-022](II_GW_Product_Specification.md#gw-fn-022) ／ [GW-FN-025](II_GW_Product_Specification.md#gw-fn-025)

**関連SYS要求：** [SYS-APP-001](../appendices/Requirements_Catalog.md)、[SYS-APP-002](../appendices/Requirements_Catalog.md)、[SYS-DATA-001](../appendices/Requirements_Catalog.md)、[SYS-DATA-002](../appendices/Requirements_Catalog.md)、[SYS-GNET-004](../appendices/Requirements_Catalog.md)、[SYS-GNET-007](../appendices/Requirements_Catalog.md)、[SYS-GSEL-013](../appendices/Requirements_Catalog.md)、[SYS-GSEL-014](../appendices/Requirements_Catalog.md)、[SYS-GWOP-001](../appendices/Requirements_Catalog.md)、[SYS-GWOP-002](../appendices/Requirements_Catalog.md)、[SYS-LOG-001](../appendices/Requirements_Catalog.md)、[SYS-MEAS-001](../appendices/Requirements_Catalog.md)、[SYS-MEAS-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-003](../appendices/Requirements_Catalog.md)、[SYS-NORTH-004](../appendices/Requirements_Catalog.md)、[SYS-NORTH-005](../appendices/Requirements_Catalog.md)、[SYS-NORTH-006](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-002](../appendices/Requirements_Catalog.md)

**根拠本文：** [09_Measurement_Data](../chapters/09_Measurement_Data.md)<br/>[13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-20-03](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-03)



<a id="s-fn-017"></a>

### S-FN-017 — 履歴の保存・提出・利用

用途別のデータを保持し、期間・品質・欠測を明示して抽出する。

**適用条件：** 保持期間・形式・制度対象は未決

**実現責任：** GW＋採用するクラウド保存／利用先

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-008](II_GW_Product_Specification.md#gw-fn-008) ／ [GW-FN-009](II_GW_Product_Specification.md#gw-fn-009)

**関連SYS要求：** [SYS-DATA-001](../appendices/Requirements_Catalog.md)、[SYS-DATA-002](../appendices/Requirements_Catalog.md)、[SYS-MEAS-001](../appendices/Requirements_Catalog.md)、[SYS-MEAS-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-006](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-002](../appendices/Requirements_Catalog.md)

**根拠本文：** [09_Measurement_Data](../chapters/09_Measurement_Data.md)

**残る確認：** [OQ-R6-09-02](../chapters/09_Measurement_Data.md#oq-r6-09-02) ／ [OQ-R6-09-03](../chapters/09_Measurement_Data.md#oq-r6-09-03)



<a id="s-fn-018"></a>

### S-FN-018 — 外部HEMSとの機器公開連携

GWがDevice側として許可する情報・操作を外部HEMSへ提供する。

**適用条件：** 仮想EL公開でRS-485 PCSの取得主体を変更しない

**実現責任：** 外部HEMS＋GW＋実機対応

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-013](II_GW_Product_Specification.md#gw-fn-013)

**関連SYS要求：** [SYS-EL-001](../appendices/Requirements_Catalog.md)、[SYS-EL-002](../appendices/Requirements_Catalog.md)、[SYS-GNET-012](../appendices/Requirements_Catalog.md)

**根拠本文：** [07_DER_Connections](../chapters/07_DER_Connections.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-07-02](../chapters/07_DER_Connections.md#oq-r6-07-02)



<a id="s-fn-019"></a>

### S-FN-019 — 利用者識別・権限・所属管理

4種類の利用者に対して、認可・失効・対象範囲・監査を適用する。

**適用条件：** 4分類は今回確定。具体権限・委譲は未承認

**実現責任：** 利用者＋GW／クラウド／製造保守の各認可境界

**根拠状態：** `R6_DESIGN_PLUS_USER_CONFIRMED_ROLE_SET`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001) ／ [GW-FN-017](II_GW_Product_Specification.md#gw-fn-017) ／ [GW-FN-025](II_GW_Product_Specification.md#gw-fn-025) ／ [GW-FN-027](II_GW_Product_Specification.md#gw-fn-027) ／ [GW-FN-028](II_GW_Product_Specification.md#gw-fn-028) ／ [GW-FN-030](II_GW_Product_Specification.md#gw-fn-030)

**関連SYS要求：** [SYS-APP-003](../appendices/Requirements_Catalog.md)、[SYS-BOUND-001](../appendices/Requirements_Catalog.md)、[SYS-CFG-003](../appendices/Requirements_Catalog.md)、[SYS-GSEL-004](../appendices/Requirements_Catalog.md)、[SYS-GSEL-006](../appendices/Requirements_Catalog.md)、[SYS-GSEL-019](../appendices/Requirements_Catalog.md)、[SYS-GWOP-001](../appendices/Requirements_Catalog.md)、[SYS-LOG-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-003](../appendices/Requirements_Catalog.md)、[SYS-NORTH-004](../appendices/Requirements_Catalog.md)、[SYS-NORTH-005](../appendices/Requirements_Catalog.md)、[SYS-NORTH-007](../appendices/Requirements_Catalog.md)、[SYS-OTA-001](../appendices/Requirements_Catalog.md)、[SYS-REQ-001](../appendices/Requirements_Catalog.md)、[SYS-SEC-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [01_Scope_Baseline](../chapters/01_Scope_Baseline.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)<br/>[27_Security_Privacy_Lifecycle](../chapters/27_Security_Privacy_Lifecycle.md)

**残る確認：** [OQ-R6-01-01](../chapters/01_Scope_Baseline.md#oq-r6-01-01) ／ [OQ-R6-27-02](../chapters/27_Security_Privacy_Lifecycle.md#oq-r6-27-02)



<a id="s-fn-020"></a>

### S-FN-020 — 製造・施工・保守・交換・廃棄支援

個体識別から引渡し、交換、所有者変更、消去まで必要な支援を定義する。

**適用条件：** 詳細機能はR6補完対象。製造試験設備等をGW内部と混同しない

**実現責任：** メーカー／メンテナンス／ユーザ＋GW＋支援基盤

**根拠状態：** `R6_COMPLETION_CANDIDATE`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-010](II_GW_Product_Specification.md#gw-fn-010) ／ [GW-FN-020](II_GW_Product_Specification.md#gw-fn-020) ／ [GW-FN-022](II_GW_Product_Specification.md#gw-fn-022) ／ [GW-FN-025](II_GW_Product_Specification.md#gw-fn-025) ／ [GW-FN-027](II_GW_Product_Specification.md#gw-fn-027) ／ [GW-FN-029](II_GW_Product_Specification.md#gw-fn-029) ／ [GW-FN-030](II_GW_Product_Specification.md#gw-fn-030) ／ [GW-FN-032](II_GW_Product_Specification.md#gw-fn-032)

**関連SYS要求：** [SYS-APP-003](../appendices/Requirements_Catalog.md)、[SYS-CAP-001](../appendices/Requirements_Catalog.md)、[SYS-CAP-002](../appendices/Requirements_Catalog.md)、[SYS-CFG-001](../appendices/Requirements_Catalog.md)、[SYS-CFG-002](../appendices/Requirements_Catalog.md)、[SYS-CFG-003](../appendices/Requirements_Catalog.md)、[SYS-CFG-004](../appendices/Requirements_Catalog.md)、[SYS-CFG-005](../appendices/Requirements_Catalog.md)、[SYS-GNET-012](../appendices/Requirements_Catalog.md)、[SYS-GSEL-011](../appendices/Requirements_Catalog.md)、[SYS-GSEL-019](../appendices/Requirements_Catalog.md)、[SYS-GWOP-001](../appendices/Requirements_Catalog.md)、[SYS-GWOP-002](../appendices/Requirements_Catalog.md)、[SYS-LOG-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-005](../appendices/Requirements_Catalog.md)、[SYS-NORTH-007](../appendices/Requirements_Catalog.md)、[SYS-OTA-002](../appendices/Requirements_Catalog.md)、[SYS-ROUTE-001](../appendices/Requirements_Catalog.md)、[SYS-SEC-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)、[SYS-SVC-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [26_Manufacturing_Commissioning_Retirement](../chapters/26_Manufacturing_Commissioning_Retirement.md)<br/>[27_Security_Privacy_Lifecycle](../chapters/27_Security_Privacy_Lifecycle.md)

**残る確認：** [OQ-R6-26-01](../chapters/26_Manufacturing_Commissioning_Retirement.md#oq-r6-26-01) ／ [OQ-R6-26-05](../chapters/26_Manufacturing_Commissioning_Retirement.md#oq-r6-26-05) ／ [OQ-R6-26-06](../chapters/26_Manufacturing_Commissioning_Retirement.md#oq-r6-26-06)



<a id="s-fn-021"></a>

### S-FN-021 — 通信・周辺機器の構成と復旧

通信方式・USB等の採用条件、接続・故障・復旧を管理する。

**適用条件：** IPv4/IPv6・Wi-SUN・USBの全対応を未確認で宣言しない

**実現責任：** GW＋宅内ルータ＋周辺機器

**根拠状態：** `R6_CARRYOVER_SCOPE_TBD`。採用リリース・実装確認・正式USDM対応は未確定。

**関係するGW機能（実装責任は別途確認）：** [GW-FN-021](II_GW_Product_Specification.md#gw-fn-021) ／ [GW-FN-026](II_GW_Product_Specification.md#gw-fn-026) ／ [GW-FN-031](II_GW_Product_Specification.md#gw-fn-031)

**関連SYS要求：** [SYS-CAP-001](../appendices/Requirements_Catalog.md)、[SYS-CFG-006](../appendices/Requirements_Catalog.md)、[SYS-EXPIRY-001](../appendices/Requirements_Catalog.md)、[SYS-FAULT-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-005](../appendices/Requirements_Catalog.md)、[SYS-GNET-006](../appendices/Requirements_Catalog.md)、[SYS-MIG-002](../appendices/Requirements_Catalog.md)、[SYS-RETRY-001](../appendices/Requirements_Catalog.md)、[SYS-SEC-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [07_DER_Connections](../chapters/07_DER_Connections.md)<br/>[18_Migration](../chapters/18_Migration.md)<br/>[22_Physical_Electrical_Installation](../chapters/22_Physical_Electrical_Installation.md)

**残る確認：** [OQ-R6-07-03](../chapters/07_DER_Connections.md#oq-r6-07-03)




## Open Questions — 本ノートの完成に必要な確認

既存OQの正本は `data/completion_items.json`。本一覧は参照で、別の回答正本を作らない。4利用者の確定事項は `data/known_answers_r7.json` を併読する。承認・数値・適合を未確認で補完しない。

| OQ・正本章 | 具体的な質問／未回答部分 | 必要資料・完了条件 |
|---|---|---|
| [OQ-R6-04-01](../chapters/04_Configurations_Profiles.md#oq-r6-04-01) | 既存GWの全機能は何か。高度エネマネ追加後に維持・変更・廃止する機能と初回採用機能はどれか。候補ではなく採用済みとできる根拠は何か。 | 機能一覧を既存仕様・コード調査と突合し、候補機能の採否・対象リリース・非対応理由を機能表で承認する。 |
| [OQ-R6-01-01](../chapters/01_Scope_Baseline.md#oq-r6-01-01) | 【一部回答済み】4分類の名称は今回確定。権限・委譲・環境等は未決。 初回製品で誰が利用・施工・管理・保守するか。各ロールの操作権限、本人確認、委譲と責任をどこまで分けるか。 | ロール×利用局面×操作範囲表を承認し、第20・26・27章へ対応付ける。 |
| [OQ-R6-04-02](../chapters/04_Configurations_Profiles.md#oq-r6-04-02) | 初回対応するPCS・空調・給湯・計測器・USB機器はどの型式/版か。全機能対応、観測のみ、非対応をどの組合せで保証するか。 | 機器プロファイルと製品構成表に実型式・版・操作・制限・確認資料を登録する。 |
| [OQ-R6-08-01](../chapters/08_Advanced_EMS_Loads.md#oq-r6-08-01) | 自家消費、料金、ピーク、充電期限のどの戦略を初回採用するか。機器構成・入力欠損・手動変更に応じた開始/解除/再開条件は何か。 | 戦略ごとの採否と機能仕様を機能表・UCへ展開し、入力/結果/異常分岐の未定を除く。 |
| [OQ-R6-21-01](../chapters/21_Grid_Connection_Selection.md#oq-r6-21-01) | EL接続PCSの自律取得能力・プロトコル・資格情報の管理仕様は何か。RS-485のGW管理と併せて、どの型式/版で実経路・公開状態を確認できるか。 | 機器接続別の取得プロファイルと管理主体、公開項目の根拠を登録する。非公開はNOT_EXPOSEDと明記する。 |
| [OQ-R6-11-02](../chapters/11_Power_Constraints.md#oq-r6-11-02) | 異なる取得主体のPCSが同じ連系点にある場合、誰が全体制約を強制するか。負荷急変時に使う評価窓・許容差・応答条件と対応外組合せは何か。 | 混在構成の成立/非対応表、過渡評価プロファイル、必要な計測・強制経路を確定する。 |
