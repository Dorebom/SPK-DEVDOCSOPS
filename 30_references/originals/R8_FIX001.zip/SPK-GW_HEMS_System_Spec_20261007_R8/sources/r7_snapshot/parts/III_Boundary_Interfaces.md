<a id="part-iii"></a>
# III. 境界インターフェース仕様

**文書状態：DRAFT_FOR_REVIEW。** 機能の一覧化・配賦整理であり、実装・機能採用・権限付与・対応機器の承認ではない。R6の27詳細章・124 SYS要求・69試験・85 OQは維持する。

## III.1 IF一覧と責務

新しいIF-IDへ改番せず、R6の16契約を参照する。複数段のアプリ→クラウド→GWを一つの通信セッションとみなさない。人の役割とサーバ接続の資格も分ける。

| 既存ID | 契約 | 両端・主体 | 主な情報 |
|---|---|---|---|
| [IF-NORTH-01](../appendices/External_Interface_Register.md) | 通常運転の上位受付 | クラウド／外部HEMS／UI → GW通常要求受付 | EnergyGoal・ControlRequest・意味的結果 |
| [IF-NORMAL-01](../appendices/External_Interface_Register.md) | 機器側通常受付 | GW通常制御 → 機器側通常受付 | 許可された通常操作と結果 |
| [IF-RS-01](../appendices/External_Interface_Register.md) | RS-485 PCS接続 | GW通信所有者 → RS-485接続PCS | 電文・応答・計測 |
| [IF-EL-01](../appendices/External_Interface_Register.md) | ECHONET Lite機器操作 | GW Controller Role → 他社機器 | 規格・プロファイルの操作と観測 |
| [IF-EL-02](../appendices/External_Interface_Register.md) | ECHONET Lite GW公開 | 外部HEMS → GW Device Role | 公開機器オブジェクトへのアクセス |
| [IF-GRID-01](../appendices/External_Interface_Register.md) | 宅内ルータ経由の出力制御取得 | EL接続PCS内OCU又はRS-485用GW G側 → 一般送配電事業者 出力制御サーバ | スケジュール等の取得・応答 |
| [IF-OBS-01](../appendices/External_Interface_Register.md) | 観測の戻り | 機器／G側 → GW観測サービス | 公開可能な状態・計測・制約コピー |
| [IF-MAINT-01](../appendices/External_Interface_Register.md) | 独立G側保守 | 独立認可主体 → G側／機器 | 許可された設定・FW保守 |
| [IF-UP-MGMT-01](../appendices/External_Interface_Register.md) | 上位管理・監視 | 上位サーバ → GW管理境界 | 設定／内部Job／情報／結果／通常要求の配送 |
| [IF-LOCAL-DIRECT-01](../appendices/External_Interface_Register.md) | 直接無線Web | 宅内ブラウザ → GW Web/API | 画面資産・状態・許可操作 |
| [IF-LOCAL-LAN-01](../appendices/External_Interface_Register.md) | ルータ経由Web | 宅内ブラウザ → ルータ経由GW Web/API | 画面資産・状態・許可操作 |
| [IF-APP-CLOUD-01](../appendices/External_Interface_Register.md) | リモートアプリ | スマートフォンアプリ → 上位クラウド | 利用者認証・所属・監視・操作結果 |
| [IF-FW-DIST-01](../appendices/External_Interface_Register.md) | FW配送 | GW Update Manager → FW配信サーバ | 画像と保護されたメタデータ |
| [IF-FW-CTL-01](../appendices/External_Interface_Register.md) | FW適用の運用契約 | 上位又は認可利用者 → GW Update Manager | 対象/配布物/方針の要求・Job状態 |
| [IF-GRID-02](../appendices/External_Interface_Register.md) | GW G側からPCSへの出力制御契約 | GW G側 → RS-485接続PCSの確認済み出力制御受付 | scope付き制約又は制約適用済み指令・応答・適用監視 |
| [IF-GRID-03](../appendices/External_Interface_Register.md) | R4対応表内の系統構成選択・適用確認 | 認可された系統保守主体 → 系統構成の所有者／PCS・GW G側 | 方式変更要求・期待世代・切替Job・実適用確認 |

## III.2 規範別冊の粒度

[IF台帳](../appendices/External_Interface_Register.md)と[具体化項目](../appendices/Interface_Contract_Detail.md)を正本候補とする。主体、開始側、経路、形式、必須項目、認証認可、設定世代、期限・再送・冪等性、エラー、版、負荷上限、監査、試験条件を定義する。

通信IFだけでなく、H/G間の論理操作境界、観測の正本と参照、電源・信号・配線の物理境界も対応付ける。詳細実装のIPC方式・構造体までは本部で決めない。

## III.3 4利用者と操作権限

各操作に [Role_Function_Access](../appendices/Role_Function_Access.md) のポリシーIDを関連付ける。受信経路が信頼できることと、依頼者が対象操作を許可されることは別。クラウドの接続認証を、すべての依頼者の無制限権限へ変換しない。

## III.4 既存詳細章との対応

| 既存章 | 扱う内容 |
|---|---|
| [02. 外部サービス・宅内接続を含むシステム構成](../chapters/02_System_Context.md) | 外部サービス・宅内接続を含むシステム構成 |
| [03. 責務・レイヤー・状態所有権](../chapters/03_Responsibilities.md) | 責務・レイヤー・状態所有権 |
| [07. DER制御・観測と方式別実行仕様](../chapters/07_DER_Connections.md) | DER制御・観測と方式別実行仕様 |
| [15. 配置案・認証影響分離境界・共有資源](../chapters/15_Deployment_Isolation.md) | 配置案・認証影響分離境界・共有資源 |
| [20. 上位管理・宅内Web UI・リモートアプリ・FW配信](../chapters/20_Northbound_Monitoring_FW.md) | 上位管理・宅内Web UI・リモートアプリ・FW配信 |
| [21. 出力制御接続方式の選択・責務・切替](../chapters/21_Grid_Connection_Selection.md) | 出力制御接続方式の選択・責務・切替 |
| [22. 物理・電気・機構・設置仕様](../chapters/22_Physical_Electrical_Installation.md) | 物理・電気・機構・設置仕様 |


## Open Questions — 本ノートの完成に必要な確認

既存OQの正本は `data/completion_items.json`。本一覧は参照で、別の回答正本を作らない。4利用者の確定事項は `data/known_answers_r7.json` を併読する。承認・数値・適合を未確認で補完しない。

| OQ・正本章 | 具体的な質問／未回答部分 | 必要資料・完了条件 |
|---|---|---|
| [OQ-R6-03-02](../chapters/03_Responsibilities.md#oq-r6-03-02) | H内及びH/G APIの必須項目、エラー体系、旧版互換、頻度・キュー上限をどの契約に固定するか。G側が受ける通常要求の許可リストは何か。 | Internal IF契約を操作単位で埋め、正規/不正/過負荷/再起動の契約試験条件を定義する。 |
| [OQ-R6-07-01](../chapters/07_DER_Connections.md#oq-r6-07-01) | 既存PCSの実プロトコル、電文/レジスタ、応答の意味、局数・配線条件は何か。通常操作とG側必須通信をどの送信者・予算で管理するか。 | PCS別接続仕様の版と電文対応を確定し、RS-485全書込点・最終送信境界・通信負荷表を登録する。 |
| [OQ-R6-07-02](../chapters/07_DER_Connections.md#oq-r6-07-02) | 機器ごとのEL/AIF版・実装プロパティ・更新間隔は何か。GWのDevice側は何を公開し、RS-485資源や他社PCSとの対応と不可応答をどう定義するか。 | 対応するEL機器と操作・観測表を埋め、Controller/Device共存、公開能力の上限、未対応応答を確認する。 |
| [OQ-R6-20-01](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-01) | 上位管理が読み書きする実項目と内部操作はどれか。プロトコル、公開schema、役割権限、完了通知・エラーをどう固定するか。 | 16件の論理IFを実契約へ展開し、公開操作台帳を実項目・権限・状態・結果へ対応付ける。 |
| [OQ-R6-27-03](../chapters/27_Security_Privacy_Lifecycle.md#oq-r6-27-03) | 各IFの暗号・認証・接続先識別・セッション方式を何にするか。従来EL機器と認証対応機器の許可操作、復号後の文脈保持をどう規定するか。 | IF別セキュリティプロファイルを確定し、失敗/混在/失効/セッションの受入条件を定義する。新たな標準暗号を全機器へ仮定しない。 |
