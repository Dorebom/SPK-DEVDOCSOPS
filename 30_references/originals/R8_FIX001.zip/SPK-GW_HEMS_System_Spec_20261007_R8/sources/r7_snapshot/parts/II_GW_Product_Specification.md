<a id="part-ii"></a>
# II. SPK-GW製品仕様

**文書状態：DRAFT_FOR_REVIEW。** 機能の一覧化・配賦整理であり、実装・機能採用・権限付与・対応機器の承認ではない。R6の27詳細章・124 SYS要求・69試験・85 OQは維持する。

## II.1 GW単体の保証範囲

本部はSPK-GW製品に配賦された振る舞いを列挙する。構成に応じたH/G双方を含む。論理機能を独立プロセス又は別CPUと断定しない。スマートフォンアプリの画面、PCS内の系統連系保護、EL接続PCSのサーバ取得はGW機能に移さない。

## II.2 SPK-GW製品の機能（要件）一覧

**32機能群。** 全体機能からGWへ割り当てる要求と支援・観測だけの関係を区別する。詳細操作・採用リリース・機器能力・数値・USDM確定は既存OQで継続する。

| GW機能ID | GWが提供する機能 | GW内の担当責務 | 上位全体機能 |
|---|---|---|---|
| [GW-FN-001](II_GW_Product_Specification.md#gw-fn-001) | 要求受付・認証認可・用途別振分け | H側の境界API・Usecase | [S-FN-002](I_System_Specification.md#s-fn-002)、[S-FN-003](I_System_Specification.md#s-fn-003)、[S-FN-004](I_System_Specification.md#s-fn-004)、[S-FN-005](I_System_Specification.md#s-fn-005)、[S-FN-009](I_System_Specification.md#s-fn-009)、[S-FN-010](I_System_Specification.md#s-fn-010)、[S-FN-019](I_System_Specification.md#s-fn-019) |
| [GW-FN-002](II_GW_Product_Specification.md#gw-fn-002) | 通常制御権・競合調停 | H側 Control Arbiter | [S-FN-004](I_System_Specification.md#s-fn-004)、[S-FN-005](I_System_Specification.md#s-fn-005)、[S-FN-006](I_System_Specification.md#s-fn-006)、[S-FN-015](I_System_Specification.md#s-fn-015) |
| [GW-FN-003](II_GW_Product_Specification.md#gw-fn-003) | 複数機器の実行進行・補償 | H側 Energy Orchestrator | [S-FN-004](I_System_Specification.md#s-fn-004)、[S-FN-005](I_System_Specification.md#s-fn-005)、[S-FN-006](I_System_Specification.md#s-fn-006)、[S-FN-007](I_System_Specification.md#s-fn-007)、[S-FN-015](I_System_Specification.md#s-fn-015) |
| [GW-FN-004](II_GW_Product_Specification.md#gw-fn-004) | DERの通常操作・達成確認 | H側 DER Power Controller | [S-FN-004](I_System_Specification.md#s-fn-004)、[S-FN-006](I_System_Specification.md#s-fn-006)、[S-FN-007](I_System_Specification.md#s-fn-007)、[S-FN-015](I_System_Specification.md#s-fn-015) |
| [GW-FN-005](II_GW_Product_Specification.md#gw-fn-005) | 空調・給湯等の負荷操作 | H側 Flexible Load Controller | [S-FN-005](I_System_Specification.md#s-fn-005)、[S-FN-006](I_System_Specification.md#s-fn-006)、[S-FN-007](I_System_Specification.md#s-fn-007) |
| [GW-FN-006](II_GW_Product_Specification.md#gw-fn-006) | 高度エネマネの計画生成 | H側 Advanced EMS | [S-FN-006](I_System_Specification.md#s-fn-006) |
| [GW-FN-007](II_GW_Product_Specification.md#gw-fn-007) | 実績評価・再計画・入力不足時縮退 | H側 Advanced EMS／Orchestrator | [S-FN-007](I_System_Specification.md#s-fn-007)、[S-FN-015](I_System_Specification.md#s-fn-015) |
| [GW-FN-008](II_GW_Product_Specification.md#gw-fn-008) | 計測・状態の取得正規化 | H側 Measurement／Device State | [S-FN-001](I_System_Specification.md#s-fn-001)、[S-FN-007](I_System_Specification.md#s-fn-007)、[S-FN-016](I_System_Specification.md#s-fn-016)、[S-FN-017](I_System_Specification.md#s-fn-017) |
| [GW-FN-009](II_GW_Product_Specification.md#gw-fn-009) | 履歴保存・抽出・上位同期 | H側 Data／Telemetry | [S-FN-001](I_System_Specification.md#s-fn-001)、[S-FN-003](I_System_Specification.md#s-fn-003)、[S-FN-016](I_System_Specification.md#s-fn-016)、[S-FN-017](I_System_Specification.md#s-fn-017) |
| [GW-FN-010](II_GW_Product_Specification.md#gw-fn-010) | 機器探索・登録・識別・能力管理 | H側 Device Inventory／Adapter | [S-FN-004](I_System_Specification.md#s-fn-004)、[S-FN-005](I_System_Specification.md#s-fn-005)、[S-FN-008](I_System_Specification.md#s-fn-008)、[S-FN-020](I_System_Specification.md#s-fn-020) |
| [GW-FN-011](II_GW_Product_Specification.md#gw-fn-011) | RS-485 PCS通常操作・状態通信 | H側要求元＋G側／固定PCS通信所有者 | [S-FN-004](I_System_Specification.md#s-fn-004)、[S-FN-008](I_System_Specification.md#s-fn-008)、[S-FN-012](I_System_Specification.md#s-fn-012) |
| [GW-FN-012](II_GW_Product_Specification.md#gw-fn-012) | ECHONET Lite Controller | H側 ECHONET Lite Controller／Adapter | [S-FN-001](I_System_Specification.md#s-fn-001)、[S-FN-004](I_System_Specification.md#s-fn-004)、[S-FN-005](I_System_Specification.md#s-fn-005)、[S-FN-008](I_System_Specification.md#s-fn-008) |
| [GW-FN-013](II_GW_Product_Specification.md#gw-fn-013) | ECHONET Lite Device側公開 | H側 ECHONET Lite Device Adapter | [S-FN-018](I_System_Specification.md#s-fn-018) |
| [GW-FN-014](II_GW_Product_Specification.md#gw-fn-014) | GW G側スケジュール取得・管理 | GW G側の出力制御機能 | [S-FN-012](I_System_Specification.md#s-fn-012) |
| [GW-FN-015](II_GW_Product_Specification.md#gw-fn-015) | GW G側の出力制御指示・必須監視 | GW G側＋確認済みPCS実行契約 | [S-FN-012](I_System_Specification.md#s-fn-012)、[S-FN-015](I_System_Specification.md#s-fn-015) |
| [GW-FN-016](II_GW_Product_Specification.md#gw-fn-016) | PCS側の出力制御・保護状態の参照 | H側の観測・公開View | [S-FN-001](I_System_Specification.md#s-fn-001)、[S-FN-013](I_System_Specification.md#s-fn-013)、[S-FN-014](I_System_Specification.md#s-fn-014)、[S-FN-016](I_System_Specification.md#s-fn-016) |
| [GW-FN-017](II_GW_Product_Specification.md#gw-fn-017) | 上位管理・監視サーバ接続 | H側 Northbound Adapter／API | [S-FN-003](I_System_Specification.md#s-fn-003)、[S-FN-009](I_System_Specification.md#s-fn-009)、[S-FN-010](I_System_Specification.md#s-fn-010)、[S-FN-016](I_System_Specification.md#s-fn-016)、[S-FN-019](I_System_Specification.md#s-fn-019) |
| [GW-FN-018](II_GW_Product_Specification.md#gw-fn-018) | 宅内Web UI提供・ローカルAPI | H側 Web／Local API | [S-FN-002](I_System_Specification.md#s-fn-002) |
| [GW-FN-019](II_GW_Product_Specification.md#gw-fn-019) | リモートアプリ用状態・結果連携 | H側上位API／クラウド向け公開View | [S-FN-003](I_System_Specification.md#s-fn-003)、[S-FN-016](I_System_Specification.md#s-fn-016) |
| [GW-FN-020](II_GW_Product_Specification.md#gw-fn-020) | 設定管理・変更調停 | H側 Configuration／各状態所有者 | [S-FN-009](I_System_Specification.md#s-fn-009)、[S-FN-015](I_System_Specification.md#s-fn-015)、[S-FN-020](I_System_Specification.md#s-fn-020) |
| [GW-FN-021](II_GW_Product_Specification.md#gw-fn-021) | ネットワーク設定の変更・到達性復旧 | H側の認可されたNetwork Config | [S-FN-009](I_System_Specification.md#s-fn-009)、[S-FN-021](I_System_Specification.md#s-fn-021) |
| [GW-FN-022](II_GW_Product_Specification.md#gw-fn-022) | 内部機能操作・ライフサイクルJob | H側 Lifecycle／Operation Service | [S-FN-010](I_System_Specification.md#s-fn-010)、[S-FN-015](I_System_Specification.md#s-fn-015)、[S-FN-016](I_System_Specification.md#s-fn-016)、[S-FN-020](I_System_Specification.md#s-fn-020) |
| [GW-FN-023](II_GW_Product_Specification.md#gw-fn-023) | FW取得・配布物検証 | H側 Update Manager（対象領域は個別管理） | [S-FN-011](I_System_Specification.md#s-fn-011) |
| [GW-FN-024](II_GW_Product_Specification.md#gw-fn-024) | FW適用・稼働確認・復旧 | H側 Update Manager／独立したG更新の境界 | [S-FN-011](I_System_Specification.md#s-fn-011)、[S-FN-015](I_System_Specification.md#s-fn-015) |
| [GW-FN-025](II_GW_Product_Specification.md#gw-fn-025) | 警報・監査・診断情報の公開 | H側 Logging／Diagnostics／Telemetry | [S-FN-016](I_System_Specification.md#s-fn-016)、[S-FN-019](I_System_Specification.md#s-fn-019)、[S-FN-020](I_System_Specification.md#s-fn-020) |
| [GW-FN-026](II_GW_Product_Specification.md#gw-fn-026) | 故障検出・再接続・結果再照合 | H側とG側それぞれの障害所有者 | [S-FN-007](I_System_Specification.md#s-fn-007)、[S-FN-015](I_System_Specification.md#s-fn-015)、[S-FN-021](I_System_Specification.md#s-fn-021) |
| [GW-FN-027](II_GW_Product_Specification.md#gw-fn-027) | 資格情報・所属・失効・認可の管理 | GW各認可境界／資格情報所有者 | [S-FN-019](I_System_Specification.md#s-fn-019)、[S-FN-020](I_System_Specification.md#s-fn-020) |
| [GW-FN-028](II_GW_Product_Specification.md#gw-fn-028) | H/G境界の限定操作・不正入力拒否 | H/G境界と最終通常送信境界 | [S-FN-012](I_System_Specification.md#s-fn-012)、[S-FN-013](I_System_Specification.md#s-fn-013)、[S-FN-014](I_System_Specification.md#s-fn-014)、[S-FN-019](I_System_Specification.md#s-fn-019) |
| [GW-FN-029](II_GW_Product_Specification.md#gw-fn-029) | 製造初期化・施工・試運転の機器側支援 | GW製造／施工用の限定機能（採否未決） | [S-FN-008](I_System_Specification.md#s-fn-008)、[S-FN-020](I_System_Specification.md#s-fn-020) |
| [GW-FN-030](II_GW_Product_Specification.md#gw-fn-030) | バックアップ・初期化・交換・消去 | H側Config／保守・個別G保守の境界 | [S-FN-009](I_System_Specification.md#s-fn-009)、[S-FN-019](I_System_Specification.md#s-fn-019)、[S-FN-020](I_System_Specification.md#s-fn-020) |
| [GW-FN-031](II_GW_Product_Specification.md#gw-fn-031) | 複数通信・USB等の接続管理 | GW通信基盤／Transport／Security Adapter | [S-FN-008](I_System_Specification.md#s-fn-008)、[S-FN-021](I_System_Specification.md#s-fn-021) |
| [GW-FN-032](II_GW_Product_Specification.md#gw-fn-032) | 起動・停止・操作開始条件の管理 | H側／G側の独立したLifecycle | [S-FN-015](I_System_Specification.md#s-fn-015)、[S-FN-020](I_System_Specification.md#s-fn-020) |

## II.3 機能要件と非機能要求のつなぎ方

IVに横断品質・制約をまとめるが、認証する・拒否する・記録する・復旧する等の必要な機構は本機能一覧にも現れる。例えば「認可機能」は本部の機能、「権限を持たない主体から保護する」という品質目標はIV、「許可操作・期限・対象・エラー」はIIIの契約に対応付ける。

非機能要求をIVへ隔離して関係を切らない。機能ごとに適用する性能、セキュリティ、安全、可用性等の要求IDを関連付ける。機能件数と要求件数は一致させない。

## II.4 利用者からの操作と自律機能

ユーザ／メンテナンス／メーカー／開発者に同じ機能の全操作を一括付与しない。監視、運転、設定、診断、更新適用、配布承認、系統保守を操作単位に分割する。

認可の判定と実行可能性は別である。提案する実行許可条件は、本人・機械主体の認証、役割の操作権限、対象住宅／機器のscope、環境・チャネル、機能採用、現在状態・Capability、期限と制御権の成立を組み合わせる。ルータ経由か直接Webかだけで権限を変えない。UIだけでなくGWの境界で拒否する。

詳細は[4利用者の機能・操作権限](../appendices/Role_Function_Access.md)。G側通常APIの禁止操作はどの利用者名でも解除できない。認可された専用保守は別契約として残す。

## II.5 既存詳細章との対応

| 既存章 | 扱う内容 |
|---|---|
| [03. 責務・レイヤー・状態所有権](../chapters/03_Responsibilities.md) | 責務・レイヤー・状態所有権 |
| [05. 通常運転要求・制御権・実行結果の契約](../chapters/05_Control_Contracts.md) | 通常運転要求・制御権・実行結果の契約 |
| [07. DER制御・観測と方式別実行仕様](../chapters/07_DER_Connections.md) | DER制御・観測と方式別実行仕様 |
| [08. 高度エネマネ・Flexible Load・運転方針](../chapters/08_Advanced_EMS_Loads.md) | 高度エネマネ・Flexible Load・運転方針 |
| [09. 計測・状態・保存・外部公開](../chapters/09_Measurement_Data.md) | 計測・状態・保存・外部公開 |
| [12. 設定管理・運用状態・ライフサイクル](../chapters/12_Configuration_Lifecycle.md) | 設定管理・運用状態・ライフサイクル |
| [13. 障害・縮退・復旧・OTA](../chapters/13_Fault_Recovery_OTA.md) | 障害・縮退・復旧・OTA |
| [20. 上位管理・宅内Web UI・リモートアプリ・FW配信](../chapters/20_Northbound_Monitoring_FW.md) | 上位管理・宅内Web UI・リモートアプリ・FW配信 |

## II.6 GW機能の適用条件・根拠カード

<a id="gw-fn-001"></a>

### GW-FN-001 — 要求受付・認証認可・用途別振分け

操作主体・対象・期限・重複を確認し、通常制御／設定／GW内部操作／情報取得／更新へ振り分ける。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側の境界API・Usecase

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-002](I_System_Specification.md#s-fn-002) ／ [S-FN-003](I_System_Specification.md#s-fn-003) ／ [S-FN-004](I_System_Specification.md#s-fn-004) ／ [S-FN-005](I_System_Specification.md#s-fn-005) ／ [S-FN-009](I_System_Specification.md#s-fn-009) ／ [S-FN-010](I_System_Specification.md#s-fn-010) ／ [S-FN-019](I_System_Specification.md#s-fn-019)

**関連SYS要求：** [SYS-REQ-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-007](../appendices/Requirements_Catalog.md)

**根拠本文：** [05_Control_Contracts](../chapters/05_Control_Contracts.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)<br/>[27_Security_Privacy_Lifecycle](../chapters/27_Security_Privacy_Lifecycle.md)

**残る確認：** [OQ-R6-20-01](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-01) ／ [OQ-R6-27-01](../chapters/27_Security_Privacy_Lifecycle.md#oq-r6-27-01)



<a id="gw-fn-002"></a>

### GW-FN-002 — 通常制御権・競合調停

資源・変換グループの権限、優先関係、世代、期限を管理する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Control Arbiter

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-004](I_System_Specification.md#s-fn-004) ／ [S-FN-005](I_System_Specification.md#s-fn-005) ／ [S-FN-006](I_System_Specification.md#s-fn-006) ／ [S-FN-015](I_System_Specification.md#s-fn-015)

**関連SYS要求：** [SYS-AUTH-001](../appendices/Requirements_Catalog.md)、[SYS-AUTH-002](../appendices/Requirements_Catalog.md)、[SYS-COEX-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [03_Responsibilities](../chapters/03_Responsibilities.md)<br/>[05_Control_Contracts](../chapters/05_Control_Contracts.md)<br/>[13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)

**残る確認：** [OQ-R6-05-01](../chapters/05_Control_Contracts.md#oq-r6-05-01)



<a id="gw-fn-003"></a>

### GW-FN-003 — 複数機器の実行進行・補償

実行順序・部分成功・取消し・補償を一つの所有者で扱い、必要なら再計画へ戻す。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Energy Orchestrator

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-004](I_System_Specification.md#s-fn-004) ／ [S-FN-005](I_System_Specification.md#s-fn-005) ／ [S-FN-006](I_System_Specification.md#s-fn-006) ／ [S-FN-007](I_System_Specification.md#s-fn-007) ／ [S-FN-015](I_System_Specification.md#s-fn-015)

**関連SYS要求：** [SYS-ORCH-001](../appendices/Requirements_Catalog.md)、[SYS-RETRY-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [03_Responsibilities](../chapters/03_Responsibilities.md)<br/>[06_Usecases](../chapters/06_Usecases.md)<br/>[13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)

**残る確認：** [OQ-R6-06-01](../chapters/06_Usecases.md#oq-r6-06-01) ／ [OQ-R6-06-02](../chapters/06_Usecases.md#oq-r6-06-02)



<a id="gw-fn-004"></a>

### GW-FN-004 — DERの通常操作・達成確認

許可済みDER要求を機器別操作系列へ展開し、受理・達成・制限・不明を区別する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 DER Power Controller

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-004](I_System_Specification.md#s-fn-004) ／ [S-FN-006](I_System_Specification.md#s-fn-006) ／ [S-FN-007](I_System_Specification.md#s-fn-007) ／ [S-FN-015](I_System_Specification.md#s-fn-015)

**関連SYS要求：** [SYS-RESP-001](../appendices/Requirements_Catalog.md)、[SYS-RESULT-001](../appendices/Requirements_Catalog.md)、[SYS-RESULT-002](../appendices/Requirements_Catalog.md)、[SYS-RESULT-003](../appendices/Requirements_Catalog.md)、[SYS-SEM-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [05_Control_Contracts](../chapters/05_Control_Contracts.md)<br/>[07_DER_Connections](../chapters/07_DER_Connections.md)

**残る確認：** [OQ-R6-05-02](../chapters/05_Control_Contracts.md#oq-r6-05-02) ／ [OQ-R6-07-01](../chapters/07_DER_Connections.md#oq-r6-07-01) ／ [OQ-R6-07-02](../chapters/07_DER_Connections.md#oq-r6-07-02)



<a id="gw-fn-005"></a>

### GW-FN-005 — 空調・給湯等の負荷操作

機器側安全・本体設定・利用可能能力を尊重して、許可済み負荷操作と結果確認を行う。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Flexible Load Controller

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-005](I_System_Specification.md#s-fn-005) ／ [S-FN-006](I_System_Specification.md#s-fn-006) ／ [S-FN-007](I_System_Specification.md#s-fn-007)

**関連SYS要求：** [SYS-LOAD-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [08_Advanced_EMS_Loads](../chapters/08_Advanced_EMS_Loads.md)

**残る確認：** [OQ-R6-08-03](../chapters/08_Advanced_EMS_Loads.md#oq-r6-08-03)



<a id="gw-fn-006"></a>

### GW-FN-006 — 高度エネマネの計画生成

計測・利用者条件・利用可能能力から運転計画を生成する。自家消費・料金・購入電力・充電期限等の採否は未決。

**適用条件：** 採用した戦略と、その必要Capabilityが成立する構成

**実現責任：** H側 Advanced EMS

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-006](I_System_Specification.md#s-fn-006)

**関連SYS要求：** [SYS-EMS-001](../appendices/Requirements_Catalog.md)、[SYS-CONST-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [08_Advanced_EMS_Loads](../chapters/08_Advanced_EMS_Loads.md)

**残る確認：** [OQ-R6-08-01](../chapters/08_Advanced_EMS_Loads.md#oq-r6-08-01) ／ [OQ-R6-08-02](../chapters/08_Advanced_EMS_Loads.md#oq-r6-08-02)



<a id="gw-fn-007"></a>

### GW-FN-007 — 実績評価・再計画・入力不足時縮退

実績・機器離脱・制約変化を評価し、再計画又は明示した縮退へ移る。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Advanced EMS／Orchestrator

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-007](I_System_Specification.md#s-fn-007) ／ [S-FN-015](I_System_Specification.md#s-fn-015)

**関連SYS要求：** [SYS-EMS-001](../appendices/Requirements_Catalog.md)、[SYS-CONST-001](../appendices/Requirements_Catalog.md)、[SYS-RESULT-002](../appendices/Requirements_Catalog.md)

**根拠本文：** [08_Advanced_EMS_Loads](../chapters/08_Advanced_EMS_Loads.md)<br/>[13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)

**残る確認：** [OQ-R6-08-02](../chapters/08_Advanced_EMS_Loads.md#oq-r6-08-02)



<a id="gw-fn-008"></a>

### GW-FN-008 — 計測・状態の取得正規化

単位・符号・計測点・鮮度・品質を保持し、同一設備や量を二重計上しない。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Measurement／Device State

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-001](I_System_Specification.md#s-fn-001) ／ [S-FN-007](I_System_Specification.md#s-fn-007) ／ [S-FN-016](I_System_Specification.md#s-fn-016) ／ [S-FN-017](I_System_Specification.md#s-fn-017)

**関連SYS要求：** [SYS-MEAS-001](../appendices/Requirements_Catalog.md)、[SYS-MEAS-002](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-002](../appendices/Requirements_Catalog.md)

**根拠本文：** [09_Measurement_Data](../chapters/09_Measurement_Data.md)<br/>[11_Power_Constraints](../chapters/11_Power_Constraints.md)

**残る確認：** [OQ-R6-09-01](../chapters/09_Measurement_Data.md#oq-r6-09-01) ／ [OQ-R6-11-01](../chapters/11_Power_Constraints.md#oq-r6-11-01)



<a id="gw-fn-009"></a>

### GW-FN-009 — 履歴保存・抽出・上位同期

短期／長期／監査の用途別保存、欠測を含む抽出と再同期を行う。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Data／Telemetry

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-001](I_System_Specification.md#s-fn-001) ／ [S-FN-003](I_System_Specification.md#s-fn-003) ／ [S-FN-016](I_System_Specification.md#s-fn-016) ／ [S-FN-017](I_System_Specification.md#s-fn-017)

**関連SYS要求：** [SYS-DATA-001](../appendices/Requirements_Catalog.md)、[SYS-DATA-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-006](../appendices/Requirements_Catalog.md)

**根拠本文：** [09_Measurement_Data](../chapters/09_Measurement_Data.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-09-02](../chapters/09_Measurement_Data.md#oq-r6-09-02) ／ [OQ-R6-09-03](../chapters/09_Measurement_Data.md#oq-r6-09-03)



<a id="gw-fn-010"></a>

### GW-FN-010 — 機器探索・登録・識別・能力管理

物理装置、資源、接続、機器オブジェクト、機器版の対応を管理し、不明能力の推測書込みをしない。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Device Inventory／Adapter

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-004](I_System_Specification.md#s-fn-004) ／ [S-FN-005](I_System_Specification.md#s-fn-005) ／ [S-FN-008](I_System_Specification.md#s-fn-008) ／ [S-FN-020](I_System_Specification.md#s-fn-020)

**関連SYS要求：** [SYS-CAP-001](../appendices/Requirements_Catalog.md)、[SYS-CAP-002](../appendices/Requirements_Catalog.md)、[SYS-ROUTE-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-012](../appendices/Requirements_Catalog.md)

**根拠本文：** [04_Configurations_Profiles](../chapters/04_Configurations_Profiles.md)<br/>[07_DER_Connections](../chapters/07_DER_Connections.md)

**残る確認：** [OQ-R6-04-02](../chapters/04_Configurations_Profiles.md#oq-r6-04-02) ／ [OQ-R6-04-03](../chapters/04_Configurations_Profiles.md#oq-r6-04-03)



<a id="gw-fn-011"></a>

### GW-FN-011 — RS-485 PCS通常操作・状態通信

既存通常操作と状態取得を維持し、G側必須指令との送信所有・負荷・非迂回契約に従って通信する。

**適用条件：** RS-485 PCS。H側からの無制限な生電文アクセスを意味しない

**実現責任：** H側要求元＋G側／固定PCS通信所有者

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-004](I_System_Specification.md#s-fn-004) ／ [S-FN-008](I_System_Specification.md#s-fn-008) ／ [S-FN-012](I_System_Specification.md#s-fn-012)

**関連SYS要求：** [SYS-RS-001](../appendices/Requirements_Catalog.md)、[SYS-RS-002](../appendices/Requirements_Catalog.md)、[SYS-RS-003](../appendices/Requirements_Catalog.md)、[SYS-RS-005](../appendices/Requirements_Catalog.md)、[SYS-RS-006](../appendices/Requirements_Catalog.md)

**根拠本文：** [04_Configurations_Profiles](../chapters/04_Configurations_Profiles.md)<br/>[07_DER_Connections](../chapters/07_DER_Connections.md)<br/>[15_Deployment_Isolation](../chapters/15_Deployment_Isolation.md)

**残る確認：** [OQ-R6-07-01](../chapters/07_DER_Connections.md#oq-r6-07-01) ／ [OQ-R6-15-01](../chapters/15_Deployment_Isolation.md#oq-r6-15-01)



<a id="gw-fn-012"></a>

### GW-FN-012 — ECHONET Lite Controller

H側LAN→宅内LAN/AP→PCS・空調・給湯・計測器のEL機器IFと、通常操作・観測の要求応答を行う。

**適用条件：** EL接続機器。PCS自身のサーバ取得とは別通信

**実現責任：** H側 ECHONET Lite Controller／Adapter

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-001](I_System_Specification.md#s-fn-001) ／ [S-FN-004](I_System_Specification.md#s-fn-004) ／ [S-FN-005](I_System_Specification.md#s-fn-005) ／ [S-FN-008](I_System_Specification.md#s-fn-008)

**関連SYS要求：** [SYS-EL-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-004](../appendices/Requirements_Catalog.md)、[SYS-CAP-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [02_System_Context](../chapters/02_System_Context.md)<br/>[07_DER_Connections](../chapters/07_DER_Connections.md)

**残る確認：** [OQ-R6-07-02](../chapters/07_DER_Connections.md#oq-r6-07-02)



<a id="gw-fn-013"></a>

### GW-FN-013 — ECHONET Lite Device側公開

外部HEMSへ許可する機器情報・操作を公開し、内部の実機対応と応答の意味を保持する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 ECHONET Lite Device Adapter

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-018](I_System_Specification.md#s-fn-018)

**関連SYS要求：** [SYS-EL-001](../appendices/Requirements_Catalog.md)、[SYS-EL-002](../appendices/Requirements_Catalog.md)、[SYS-GNET-012](../appendices/Requirements_Catalog.md)

**根拠本文：** [07_DER_Connections](../chapters/07_DER_Connections.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-07-02](../chapters/07_DER_Connections.md#oq-r6-07-02)



<a id="gw-fn-014"></a>

### GW-FN-014 — GW G側スケジュール取得・管理

宅内ルータ経由で出力制御情報を取得・検証・保存し、適用時刻・有効性・資格情報を管理する。

**適用条件：** RS-485 PCS向けGW_MANAGED。EL PCSの代理取得には使用しない

**実現責任：** GW G側の出力制御機能

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-012](I_System_Specification.md#s-fn-012)

**関連SYS要求：** [SYS-GRID-001](../appendices/Requirements_Catalog.md)、[SYS-GRID-003](../appendices/Requirements_Catalog.md)、[SYS-GSEL-001](../appendices/Requirements_Catalog.md)、[SYS-GSEL-005](../appendices/Requirements_Catalog.md)、[SYS-GSEL-006](../appendices/Requirements_Catalog.md)、[SYS-GNET-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-003](../appendices/Requirements_Catalog.md)

**根拠本文：** [10_Grid_Protection](../chapters/10_Grid_Protection.md)<br/>[21_Grid_Connection_Selection](../chapters/21_Grid_Connection_Selection.md)

**残る確認：** [OQ-R6-10-01](../chapters/10_Grid_Protection.md#oq-r6-10-01) ／ [OQ-R6-21-01](../chapters/21_Grid_Connection_Selection.md#oq-r6-21-01)



<a id="gw-fn-015"></a>

### GW-FN-015 — GW G側の出力制御指示・必須監視

適用制約に従いRS-485 PCSへ指示し、必要な状態・通信異常を監視する。

**適用条件：** RS-485 PCS。H側停止とGW全体停止は別条件

**実現責任：** GW G側＋確認済みPCS実行契約

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-012](I_System_Specification.md#s-fn-012) ／ [S-FN-015](I_System_Specification.md#s-fn-015)

**関連SYS要求：** [SYS-GSEL-004](../appendices/Requirements_Catalog.md)、[SYS-GSEL-005](../appendices/Requirements_Catalog.md)、[SYS-GSEL-011](../appendices/Requirements_Catalog.md)、[SYS-GSEL-012](../appendices/Requirements_Catalog.md)、[SYS-GNET-003](../appendices/Requirements_Catalog.md)

**根拠本文：** [10_Grid_Protection](../chapters/10_Grid_Protection.md)<br/>[15_Deployment_Isolation](../chapters/15_Deployment_Isolation.md)<br/>[21_Grid_Connection_Selection](../chapters/21_Grid_Connection_Selection.md)

**残る確認：** [OQ-R6-10-02](../chapters/10_Grid_Protection.md#oq-r6-10-02) ／ [OQ-R6-15-01](../chapters/15_Deployment_Isolation.md#oq-r6-15-01) ／ [OQ-R6-21-01](../chapters/21_Grid_Connection_Selection.md#oq-r6-21-01)



<a id="gw-fn-016"></a>

### GW-FN-016 — PCS側の出力制御・保護状態の参照

提供可能な制約・状態だけを参照する。非公開は不明とし、EL PCSの取得・適用やPCS保護そのものを代行しない。

**適用条件：** PCSが公開する情報の範囲内。OBSERVE_ONLYの配賦

**実現責任：** H側の観測・公開View

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-001](I_System_Specification.md#s-fn-001) ／ [S-FN-013](I_System_Specification.md#s-fn-013) ／ [S-FN-014](I_System_Specification.md#s-fn-014) ／ [S-FN-016](I_System_Specification.md#s-fn-016)

**関連SYS要求：** [SYS-GSEL-013](../appendices/Requirements_Catalog.md)、[SYS-GSEL-014](../appendices/Requirements_Catalog.md)、[SYS-GNET-007](../appendices/Requirements_Catalog.md)、[SYS-GNET-004](../appendices/Requirements_Catalog.md)

**根拠本文：** [09_Measurement_Data](../chapters/09_Measurement_Data.md)<br/>[10_Grid_Protection](../chapters/10_Grid_Protection.md)<br/>[21_Grid_Connection_Selection](../chapters/21_Grid_Connection_Selection.md)

**残る確認：** [OQ-R6-21-01](../chapters/21_Grid_Connection_Selection.md#oq-r6-21-01) ／ [OQ-R6-09-01](../chapters/09_Measurement_Data.md#oq-r6-09-01)



<a id="gw-fn-017"></a>

### GW-FN-017 — 上位管理・監視サーバ接続

認可された要求を用途別に配送し、状態・結果・内部情報の許可項目を公開する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Northbound Adapter／API

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-003](I_System_Specification.md#s-fn-003) ／ [S-FN-009](I_System_Specification.md#s-fn-009) ／ [S-FN-010](I_System_Specification.md#s-fn-010) ／ [S-FN-016](I_System_Specification.md#s-fn-016) ／ [S-FN-019](I_System_Specification.md#s-fn-019)

**関連SYS要求：** [SYS-NORTH-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-003](../appendices/Requirements_Catalog.md)、[SYS-NORTH-004](../appendices/Requirements_Catalog.md)、[SYS-NORTH-005](../appendices/Requirements_Catalog.md)、[SYS-GWOP-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-20-01](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-01) ／ [OQ-R6-20-05](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-05)



<a id="gw-fn-018"></a>

### GW-FN-018 — 宅内Web UI提供・ローカルAPI

直接無線又は宅内ルータ経由の端末に、基本監視・許可操作を提供する。

**適用条件：** 直接方式・AP/STA同時動作・画面範囲は未決。サーバ回線の代替ではない

**実現責任：** H側 Web／Local API

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-002](I_System_Specification.md#s-fn-002)

**関連SYS要求：** [SYS-UI-001](../appendices/Requirements_Catalog.md)、[SYS-UI-002](../appendices/Requirements_Catalog.md)、[SYS-UI-003](../appendices/Requirements_Catalog.md)、[SYS-UI-004](../appendices/Requirements_Catalog.md)、[SYS-UI-005](../appendices/Requirements_Catalog.md)、[SYS-GNET-010](../appendices/Requirements_Catalog.md)

**根拠本文：** [02_System_Context](../chapters/02_System_Context.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-02-02](../chapters/02_System_Context.md#oq-r6-02-02) ／ [OQ-R6-20-02](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-02)



<a id="gw-fn-019"></a>

### GW-FN-019 — リモートアプリ用状態・結果連携

GWはクラウドへ状態・操作結果を返す。スマートフォン画面やアプリ実装そのものをGW内機能にしない。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側上位API／クラウド向け公開View

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-003](I_System_Specification.md#s-fn-003) ／ [S-FN-016](I_System_Specification.md#s-fn-016)

**関連SYS要求：** [SYS-APP-001](../appendices/Requirements_Catalog.md)、[SYS-APP-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-006](../appendices/Requirements_Catalog.md)、[SYS-STATE-002](../appendices/Requirements_Catalog.md)

**根拠本文：** [20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-20-02](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-02) ／ [OQ-R6-20-05](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-05)



<a id="gw-fn-020"></a>

### GW-FN-020 — 設定管理・変更調停

設定の希望・保存・有効状態、世代競合、反映可否、部分反映、通常と緊急復旧を区別する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Configuration／各状態所有者

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-009](I_System_Specification.md#s-fn-009) ／ [S-FN-015](I_System_Specification.md#s-fn-015) ／ [S-FN-020](I_System_Specification.md#s-fn-020)

**関連SYS要求：** [SYS-CFG-001](../appendices/Requirements_Catalog.md)、[SYS-CFG-002](../appendices/Requirements_Catalog.md)、[SYS-CFG-004](../appendices/Requirements_Catalog.md)、[SYS-CFG-005](../appendices/Requirements_Catalog.md)

**根拠本文：** [12_Configuration_Lifecycle](../chapters/12_Configuration_Lifecycle.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-12-02](../chapters/12_Configuration_Lifecycle.md#oq-r6-12-02) ／ [OQ-R6-12-03](../chapters/12_Configuration_Lifecycle.md#oq-r6-12-03)



<a id="gw-fn-021"></a>

### GW-FN-021 — ネットワーク設定の変更・到達性復旧

接続設定を変更し、適用結果と到達性を確認して規定された復旧へ移る。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側の認可されたNetwork Config

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-009](I_System_Specification.md#s-fn-009) ／ [S-FN-021](I_System_Specification.md#s-fn-021)

**関連SYS要求：** [SYS-CFG-006](../appendices/Requirements_Catalog.md)、[SYS-GNET-006](../appendices/Requirements_Catalog.md)

**根拠本文：** [12_Configuration_Lifecycle](../chapters/12_Configuration_Lifecycle.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-26-03](../chapters/26_Manufacturing_Commissioning_Retirement.md#oq-r6-26-03) ／ [OQ-R6-12-02](../chapters/12_Configuration_Lifecycle.md#oq-r6-12-02)



<a id="gw-fn-022"></a>

### GW-FN-022 — 内部機能操作・ライフサイクルJob

許可リスト内の探索・開始停止・再起動・診断等をJobとして処理し、高影響操作を調整する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Lifecycle／Operation Service

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-010](I_System_Specification.md#s-fn-010) ／ [S-FN-015](I_System_Specification.md#s-fn-015) ／ [S-FN-016](I_System_Specification.md#s-fn-016) ／ [S-FN-020](I_System_Specification.md#s-fn-020)

**関連SYS要求：** [SYS-GWOP-001](../appendices/Requirements_Catalog.md)、[SYS-GWOP-002](../appendices/Requirements_Catalog.md)

**根拠本文：** [12_Configuration_Lifecycle](../chapters/12_Configuration_Lifecycle.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-20-01](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-01)



<a id="gw-fn-023"></a>

### GW-FN-023 — FW取得・配布物検証

配信・承認・適用を分け、対象・完全性・互換性・系列を確認する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Update Manager（対象領域は個別管理）

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-011](I_System_Specification.md#s-fn-011)

**関連SYS要求：** [SYS-FW-001](../appendices/Requirements_Catalog.md)、[SYS-FW-002](../appendices/Requirements_Catalog.md)、[SYS-FW-005](../appendices/Requirements_Catalog.md)

**根拠本文：** [13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-20-04](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-04)



<a id="gw-fn-024"></a>

### GW-FN-024 — FW適用・稼働確認・復旧

許可された更新を実行し、永続状態に基づいて復帰・旧要求照合を行う。H更新にG更新を混入させない。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Update Manager／独立したG更新の境界

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-011](I_System_Specification.md#s-fn-011) ／ [S-FN-015](I_System_Specification.md#s-fn-015)

**関連SYS要求：** [SYS-OTA-001](../appendices/Requirements_Catalog.md)、[SYS-OTA-002](../appendices/Requirements_Catalog.md)、[SYS-FW-003](../appendices/Requirements_Catalog.md)、[SYS-FW-004](../appendices/Requirements_Catalog.md)

**根拠本文：** [13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-20-04](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-04) ／ [OQ-R6-13-02](../chapters/13_Fault_Recovery_OTA.md#oq-r6-13-02)



<a id="gw-fn-025"></a>

### GW-FN-025 — 警報・監査・診断情報の公開

故障・操作・品質・相関情報を記録し、許可された警報・診断情報を通知・抽出する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側 Logging／Diagnostics／Telemetry

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-016](I_System_Specification.md#s-fn-016) ／ [S-FN-019](I_System_Specification.md#s-fn-019) ／ [S-FN-020](I_System_Specification.md#s-fn-020)

**関連SYS要求：** [SYS-LOG-001](../appendices/Requirements_Catalog.md)、[SYS-STATE-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-005](../appendices/Requirements_Catalog.md)

**根拠本文：** [09_Measurement_Data](../chapters/09_Measurement_Data.md)<br/>[13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)

**残る確認：** [OQ-R6-20-03](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-03) ／ [OQ-R6-09-03](../chapters/09_Measurement_Data.md#oq-r6-09-03)



<a id="gw-fn-026"></a>

### GW-FN-026 — 故障検出・再接続・結果再照合

WAN/LAN/GW/RS-485等の障害位置を区別し、要求残留・期限・重複を照合して縮退・復旧する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側とG側それぞれの障害所有者

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-007](I_System_Specification.md#s-fn-007) ／ [S-FN-015](I_System_Specification.md#s-fn-015) ／ [S-FN-021](I_System_Specification.md#s-fn-021)

**関連SYS要求：** [SYS-FAULT-001](../appendices/Requirements_Catalog.md)、[SYS-EXPIRY-001](../appendices/Requirements_Catalog.md)、[SYS-RETRY-001](../appendices/Requirements_Catalog.md)、[SYS-GNET-005](../appendices/Requirements_Catalog.md)

**根拠本文：** [13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)<br/>[21_Grid_Connection_Selection](../chapters/21_Grid_Connection_Selection.md)

**残る確認：** [OQ-R6-13-01](../chapters/13_Fault_Recovery_OTA.md#oq-r6-13-01) ／ [OQ-R6-20-05](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-05)



<a id="gw-fn-027"></a>

### GW-FN-027 — 資格情報・所属・失効・認可の管理

操作者と配送主体を区別し、所属変更・資格情報の更新失効・環境と対象範囲に従ってアクセスを制限する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** GW各認可境界／資格情報所有者

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-019](I_System_Specification.md#s-fn-019) ／ [S-FN-020](I_System_Specification.md#s-fn-020)

**関連SYS要求：** [SYS-SEC-001](../appendices/Requirements_Catalog.md)、[SYS-NORTH-002](../appendices/Requirements_Catalog.md)、[SYS-NORTH-007](../appendices/Requirements_Catalog.md)、[SYS-APP-003](../appendices/Requirements_Catalog.md)

**根拠本文：** [14_Performance_Security](../chapters/14_Performance_Security.md)<br/>[20_Northbound_Monitoring_FW](../chapters/20_Northbound_Monitoring_FW.md)<br/>[27_Security_Privacy_Lifecycle](../chapters/27_Security_Privacy_Lifecycle.md)

**残る確認：** [OQ-R6-27-02](../chapters/27_Security_Privacy_Lifecycle.md#oq-r6-27-02) ／ [OQ-R6-27-03](../chapters/27_Security_Privacy_Lifecycle.md#oq-r6-27-03) ／ [OQ-R6-27-04](../chapters/27_Security_Privacy_Lifecycle.md#oq-r6-27-04)



<a id="gw-fn-028"></a>

### GW-FN-028 — H/G境界の限定操作・不正入力拒否

通常APIから保護設定・系統スケジュール原本等へ迂回させず、専用保守と通常権限を分ける。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H/G境界と最終通常送信境界

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-012](I_System_Specification.md#s-fn-012) ／ [S-FN-013](I_System_Specification.md#s-fn-013) ／ [S-FN-014](I_System_Specification.md#s-fn-014) ／ [S-FN-019](I_System_Specification.md#s-fn-019)

**関連SYS要求：** [SYS-BOUND-001](../appendices/Requirements_Catalog.md)、[SYS-GSEL-004](../appendices/Requirements_Catalog.md)、[SYS-GSEL-006](../appendices/Requirements_Catalog.md)、[SYS-OTA-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [05_Control_Contracts](../chapters/05_Control_Contracts.md)<br/>[15_Deployment_Isolation](../chapters/15_Deployment_Isolation.md)<br/>[27_Security_Privacy_Lifecycle](../chapters/27_Security_Privacy_Lifecycle.md)

**残る確認：** [OQ-R6-03-02](../chapters/03_Responsibilities.md#oq-r6-03-02) ／ [OQ-R6-15-02](../chapters/15_Deployment_Isolation.md#oq-r6-15-02)



<a id="gw-fn-029"></a>

### GW-FN-029 — 製造初期化・施工・試運転の機器側支援

個体識別・初期設定・登録・引渡し確認に必要な機器側機能を定義する。詳細機能はR6補完対象。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** GW製造／施工用の限定機能（採否未決）

**根拠状態：** `R6_COMPLETION_CANDIDATE`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-008](I_System_Specification.md#s-fn-008) ／ [S-FN-020](I_System_Specification.md#s-fn-020)

**関連SYS要求：** [SYS-GSEL-019](../appendices/Requirements_Catalog.md)、[SYS-SVC-001](../appendices/Requirements_Catalog.md)

**根拠本文：** [26_Manufacturing_Commissioning_Retirement](../chapters/26_Manufacturing_Commissioning_Retirement.md)

**残る確認：** [OQ-R6-26-01](../chapters/26_Manufacturing_Commissioning_Retirement.md#oq-r6-26-01) ／ [OQ-R6-26-02](../chapters/26_Manufacturing_Commissioning_Retirement.md#oq-r6-26-02) ／ [OQ-R6-26-03](../chapters/26_Manufacturing_Commissioning_Retirement.md#oq-r6-26-03) ／ [OQ-R6-26-04](../chapters/26_Manufacturing_Commissioning_Retirement.md#oq-r6-26-04)



<a id="gw-fn-030"></a>

### GW-FN-030 — バックアップ・初期化・交換・消去

設定復元の境界を保ち、交換・所有者変更・廃棄で対象データと資格を整理する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側Config／保守・個別G保守の境界

**根拠状態：** `R6_COMPLETION_CANDIDATE`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-009](I_System_Specification.md#s-fn-009) ／ [S-FN-019](I_System_Specification.md#s-fn-019) ／ [S-FN-020](I_System_Specification.md#s-fn-020)

**関連SYS要求：** [SYS-CFG-003](../appendices/Requirements_Catalog.md)、[SYS-APP-003](../appendices/Requirements_Catalog.md)、[SYS-GSEL-019](../appendices/Requirements_Catalog.md)

**根拠本文：** [12_Configuration_Lifecycle](../chapters/12_Configuration_Lifecycle.md)<br/>[26_Manufacturing_Commissioning_Retirement](../chapters/26_Manufacturing_Commissioning_Retirement.md)<br/>[27_Security_Privacy_Lifecycle](../chapters/27_Security_Privacy_Lifecycle.md)

**残る確認：** [OQ-R6-12-04](../chapters/12_Configuration_Lifecycle.md#oq-r6-12-04) ／ [OQ-R6-26-05](../chapters/26_Manufacturing_Commissioning_Retirement.md#oq-r6-26-05) ／ [OQ-R6-26-06](../chapters/26_Manufacturing_Commissioning_Retirement.md#oq-r6-26-06)



<a id="gw-fn-031"></a>

### GW-FN-031 — 複数通信・USB等の接続管理

IPv4/IPv6・Wi-SUN・USB等の持越し要求について、搭載・有効・接続・認証・故障を区別する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** GW通信基盤／Transport／Security Adapter

**根拠状態：** `R6_CARRYOVER_SCOPE_TBD`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-008](I_System_Specification.md#s-fn-008) ／ [S-FN-021](I_System_Specification.md#s-fn-021)

**関連SYS要求：** [SYS-SEC-001](../appendices/Requirements_Catalog.md)、[SYS-CAP-001](../appendices/Requirements_Catalog.md)、[SYS-MIG-002](../appendices/Requirements_Catalog.md)

**根拠本文：** [07_DER_Connections](../chapters/07_DER_Connections.md)<br/>[18_Migration](../chapters/18_Migration.md)

**残る確認：** [OQ-R6-07-03](../chapters/07_DER_Connections.md#oq-r6-07-03) ／ [OQ-R6-18-01](../chapters/18_Migration.md#oq-r6-18-01)



<a id="gw-fn-032"></a>

### GW-FN-032 — 起動・停止・操作開始条件の管理

設定・時計・機器・旧要求の照合結果に応じ、監視・通常制御・自律制御を段階的に許可する。

**適用条件：** 対象機器・版・操作・状態・数値の確定後に適用

**実現責任：** H側／G側の独立したLifecycle

**根拠状態：** `R6_DESIGN_DRAFT`。採用リリース・実装確認・正式USDM対応は未確定。

**上位の全体機能：** [S-FN-015](I_System_Specification.md#s-fn-015) ／ [S-FN-020](I_System_Specification.md#s-fn-020)

**関連SYS要求：** [SYS-OTA-002](../appendices/Requirements_Catalog.md)、[SYS-CAP-002](../appendices/Requirements_Catalog.md)、[SYS-GSEL-011](../appendices/Requirements_Catalog.md)

**根拠本文：** [12_Configuration_Lifecycle](../chapters/12_Configuration_Lifecycle.md)<br/>[13_Fault_Recovery_OTA](../chapters/13_Fault_Recovery_OTA.md)

**残る確認：** [OQ-R6-12-01](../chapters/12_Configuration_Lifecycle.md#oq-r6-12-01) ／ [OQ-R6-13-02](../chapters/13_Fault_Recovery_OTA.md#oq-r6-13-02)




## Open Questions — 本ノートの完成に必要な確認

既存OQの正本は `data/completion_items.json`。本一覧は参照で、別の回答正本を作らない。4利用者の確定事項は `data/known_answers_r7.json` を併読する。承認・数値・適合を未確認で補完しない。

| OQ・正本章 | 具体的な質問／未回答部分 | 必要資料・完了条件 |
|---|---|---|
| [OQ-R6-04-01](../chapters/04_Configurations_Profiles.md#oq-r6-04-01) | 既存GWの全機能は何か。高度エネマネ追加後に維持・変更・廃止する機能と初回採用機能はどれか。候補ではなく採用済みとできる根拠は何か。 | 機能一覧を既存仕様・コード調査と突合し、候補機能の採否・対象リリース・非対応理由を機能表で承認する。 |
| [OQ-R6-05-01](../chapters/05_Control_Contracts.md#oq-r6-05-01) | 利用者、本体操作、各クラウド、既存運転、高度エネマネが競合するとき、操作別の優先順位と同順位処理をどう決めるか。途中実行の取消しをどこまで保証するか。 | 通常操作の優先表、同時実行許可表、要求失効と補償の決定表を機器能力と対応付ける。 |
| [OQ-R6-07-01](../chapters/07_DER_Connections.md#oq-r6-07-01) | 既存PCSの実プロトコル、電文/レジスタ、応答の意味、局数・配線条件は何か。通常操作とG側必須通信をどの送信者・予算で管理するか。 | PCS別接続仕様の版と電文対応を確定し、RS-485全書込点・最終送信境界・通信負荷表を登録する。 |
| [OQ-R6-07-02](../chapters/07_DER_Connections.md#oq-r6-07-02) | 機器ごとのEL/AIF版・実装プロパティ・更新間隔は何か。GWのDevice側は何を公開し、RS-485資源や他社PCSとの対応と不可応答をどう定義するか。 | 対応するEL機器と操作・観測表を埋め、Controller/Device共存、公開能力の上限、未対応応答を確認する。 |
| [OQ-R6-20-01](../chapters/20_Northbound_Monitoring_FW.md#oq-r6-20-01) | 上位管理が読み書きする実項目と内部操作はどれか。プロトコル、公開schema、役割権限、完了通知・エラーをどう固定するか。 | 16件の論理IFを実契約へ展開し、公開操作台帳を実項目・権限・状態・結果へ対応付ける。 |
| [OQ-R6-01-01](../chapters/01_Scope_Baseline.md#oq-r6-01-01) | 【一部回答済み】4分類の名称は今回確定。権限・委譲・環境等は未決。 初回製品で誰が利用・施工・管理・保守するか。各ロールの操作権限、本人確認、委譲と責任をどこまで分けるか。 | ロール×利用局面×操作範囲表を承認し、第20・26・27章へ対応付ける。 |
| [OQ-R6-19-01](../chapters/19_Open_Issues_Sources.md#oq-r6-19-01) | 正式USDMの正本・IDは何か。124件のSYSと今回の補完項目を誰が要求へ対応付け、重複・不足・対象外を承認するか。 | USDM→機能→SYS/補完項目→設計→検証の対応を版付きで完成し、未記入を適合扱いしない。 |
