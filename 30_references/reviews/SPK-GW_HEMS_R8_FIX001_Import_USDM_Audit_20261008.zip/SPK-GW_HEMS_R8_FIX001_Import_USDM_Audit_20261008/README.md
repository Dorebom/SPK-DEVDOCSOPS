# R8-FIX001 取り込み・USDM展開の準備性監査

Review.mdが報告書です。製品仕様の変更パッケージではありません。

probe_results.jsonは9種類の合成変更と原本確認の実行記録です。PASSは既存検査器の応答であり、不正データの安全性を意味しません。
audit_facts.jsonは入力ハッシュ、対象件数、コード位置を保持します。

再現：
```text
python reproduce_audit.py "SPK-GW_HEMS_System_Spec_20261007_R8_FIX001(1).zip" --out audit_results
```

入力ZIPのハッシュを検査し、一時コピーだけを変更します。実Word／Excelの抽出精度・大量文書性能・製品／実機／認証試験は未実施です。
