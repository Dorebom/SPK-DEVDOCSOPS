#!/usr/bin/env python3
"""R8-FIX001文書ツール監査。入力ZIP不変、合成変更は一時コピーだけ。
これはWord/Excelの実抽出試験・製品機能試験ではない。
"""
from __future__ import annotations
import argparse, copy, hashlib, json, re, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
EXPECTED_SHA='ff984bda9214c9d874640cf078087da40674b0eb379babb5c597fed8085481e2'
ROOT_NAME='SPK-GW_HEMS_System_Spec_20261007_R8'
def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def load(root:Path,name:str):return json.loads((root/name).read_text(encoding='utf-8'))
def save(root:Path,name:str,obj): (root/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def run(root:Path,tool:str,*args:str):
 p=subprocess.run([sys.executable,str(root/'tools'/tool),*args],capture_output=True,text=True,timeout=30,cwd=root)
 result={'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 if tool=='validate_r8.py' and (root/'data/document_validation_r8.json').exists():
  d=load(root,'data/document_validation_r8.json');result.update(result=d['result'],checks=len(d['checks']),failed_checks=[x['check'] for x in d['errors']],report=d)
 return result
def main():
 ap=argparse.ArgumentParser();ap.add_argument('zip',type=Path);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 raw=a.zip.read_bytes();h=sha(raw)
 if h!=EXPECTED_SHA:raise ValueError('本スクリプトは監査済み入力ZIPのハッシュだけを許可します。別版の同梱コードは先にレビューしてください。')
 with tempfile.TemporaryDirectory(prefix='spkgw_import_audit_') as td:
  base=Path(td)/'base'
  with zipfile.ZipFile(a.zip) as z:
   for i in z.infolist():
    if not (base/i.filename).resolve().is_relative_to(base.resolve()):raise ValueError(i.filename)
   z.extractall(base)
  pristine=base/ROOT_NAME
  results=[]
  def case(name,desc,mutate=None,sync=True):
   r=Path(td)/name/ROOT_NAME;shutil.copytree(pristine,r)
   if mutate:mutate(r)
   rec={'id':name,'description':desc,'synthetic':mutate is not None}
   if sync:rec['sync']=run(r,'sync_views.py')
   rec['validate']=run(r,'validate_r8.py')
   results.append(rec);print(name,rec['validate']['result'],rec['validate']['failed_checks'],flush=True)
   return r,rec
  r,rec=case('B01','原本コピーの文書検証',sync=False)
  rec['baseline_check']=run(r,'validate_r8.py','--baseline-check')
  rec['distribution']=run(r,'verify_distribution_fix001.py',str(a.zip.resolve()))
  r,rec=case('B02','変更なしで再生成した後の文書検証')
  rec['changed_after_sync']=[p.relative_to(pristine).as_posix() for p in pristine.rglob('*') if p.is_file() and p.relative_to(pristine).as_posix()!='data/document_validation_r8.json' and (r/p.relative_to(pristine)).read_bytes()!=p.read_bytes()]
  def new_req(r):
   d=load(r,'data/requirements.json');x=copy.deepcopy(d['requirements'][0]);x['id']='SYS-AUDIT-EXT-001';x['title']='合成試験：新しい要求';x['requirement']='合成試験用の要求を一意な識別子で管理すること。実製品仕様ではない。';d['requirements'].append(x);save(r,'data/requirements.json',d)
  r,rec=case('P01','有効な形の新規SYS要求を1件追加し、ビューも再生成',new_req)
  rec['requirement_count']=len(load(r,'data/requirements.json')['requirements']);rec['catalog_heading']=(r/'appendices/Requirements_Catalog.md').read_text().splitlines()[0]
  def bad_source(r):
   d=load(r,'data/requirements.json');d['requirements'][0]['source_ids']=['MISSING-DOCUMENT-AUDIT-001'];save(r,'data/requirements.json',d)
  case('P02','存在しない出典IDに置換し、ビューも再生成',bad_source)
  def bad_usdm(r):
   d=load(r,'data/requirements.json');d['requirements'][0]['usdm_id']='MISSING-USDM-AUDIT-001';save(r,'data/requirements.json',d)
  case('P03','存在しないUSDM IDを割り当て、ビューも再生成',bad_usdm)
  def blank_req(r):
   d=load(r,'data/requirements.json');d['requirements'][0]['requirement']='';save(r,'data/requirements.json',d)
  case('P04','要求本文を空文字にしてビューも再生成',blank_req)
  def stale_view(r):
   d=load(r,'data/requirements.json');d['requirements'][0]['requirement']='合成試験：元の要求本文と意図的に異なる記述。';save(r,'data/requirements.json',d)
  case('P05','要求JSONだけ変更し、生成ビューを古いまま検証',stale_view,sync=False)
  def broken_test_relation(r):
   d=load(r,'data/requirements.json');x=next(x for x in d['requirements'] if x['id']=='SYS-GRID-001');x['verification_ids']=['T19'];save(r,'data/requirements.json',d)
  case('P06','既存テストIDで逆方向対応と食い違うリンクに変え、ビューを再生成',broken_test_relation)
  def dup_req(r):
   d=load(r,'data/requirements.json');x=copy.deepcopy(d['requirements'][0]);x['requirement']='合成試験：同一IDの別内容。';d['requirements'].append(x);save(r,'data/requirements.json',d)
  r,rec=case('P07','同一IDの異内容レコードを追加、再生成前に検証',dup_req,sync=False)
  rec['after_sync']=run(r,'sync_views.py');rec['after_sync_validate']=run(r,'validate_r8.py')
  # Exercise batch atomicity: a valid OQ edit followed by a bad function record.
  r=Path(td)/'P08'/ROOT_NAME;shutil.copytree(pristine,r)
  qs=load(r,'data/completion_items.json')['items'];q=qs[0];path=r/q['note'];txt=path.read_text();anchor=f'<a id="{q["question_id"].lower()}"></a>';left,right=txt.split(anchor,1);right=right.replace('**回答：** 未記入。','**回答：** 合成試験の途中回答。',1);path.write_text(left+anchor+right)
  fc=load(r,'data/function_catalog.json');del fc['system_functions'][0]['behavior'];save(r,'data/function_catalog.json',fc)
  tracked=['data/completion_items.json','chapters/I_System/I-03_System_Functions.md','chapters/II_GW/II-02_GW_Functions.md','appendices/Open_Question_Register.md','90_All_In_One.md']
  before={p:sha((r/p).read_bytes()) for p in tracked};sy=run(r,'sync_views.py');after={p:sha((r/p).read_bytes()) for p in tracked}
  rec={'id':'P08','description':'OQ回答変更＋機能レコード欠落で生成エラーを起こし、途中書込みを確認','synthetic':True,'sync':sy,'changed_generated_files':[p for p in tracked if before[p]!=after[p]],'oq_json_answer_after_failure':load(r,'data/completion_items.json')['items'][0]['answer']};results.append(rec);print('P08',sy['returncode'],rec['changed_generated_files'],flush=True)
  # Requirement metadata type is currently unvalidated and ignored by generation.
  def wrong_type(r):
   d=load(r,'data/requirements.json');d['requirements'][0]['status']=12345;save(r,'data/requirements.json',d)
  case('P09','要求状態に不正な数値型を与えてビューも再生成',wrong_type)
  summary={'input_name':a.zip.name,'input_sha256':h,'original_unchanged':sha(a.zip.read_bytes())==h,'scope':'文書管理・生成・検証ツールの合成試験。実Word/Excel抽出・製品・実機・認証試験ではない。','cases':results}
  save(a.out,'probe_results.json',summary)
  for c in results:
   for key in ['validate','baseline_check','distribution','sync','after_sync','after_sync_validate']:
    if key in c:save(a.out,f'{c["id"]}_{key}.json',c[key])
if __name__=='__main__':main()
